/**
 * Frontend script for the Tutor LMS courses filter block.
 * Loaded via viewScript in block.json on the frontend, and via enqueue_block_editor_assets
 * in the editor (so the filter buttons work in the ServerSideRender preview).
 */
(function() {
	function initTCF() {
		var wrappers = document.querySelectorAll(".tutor-courses-filter-wrapper");
		if (!wrappers.length) return;

		wrappers.forEach(function(wrapper) {
			if (wrapper.getAttribute("data-tcf-ready") === "1") return;
			wrapper.setAttribute("data-tcf-ready", "1");

			var buttons = wrapper.querySelectorAll(".tcf-btn");
			var lists   = wrapper.querySelector(".tutor-courses-filter-lists");
			if (!lists) return;
			var loading = null;

			function buildUrl(term) {
				var d = wrapper.dataset;
				var url = d.tcfRest + "?term=" + encodeURIComponent(term)
					+ "&orderby=" + encodeURIComponent(d.tcfOrderby || "date")
					+ "&perPage=" + encodeURIComponent(d.tcfPerpage || 3);
				["showLevel","showRating","showLessons","showDuration","showPrice","showStudents","showEnrollBtn","enrollBtnText","openInNewTab"].forEach(function(k) {
					var attr = "tcf" + k.charAt(0).toUpperCase() + k.slice(1).toLowerCase();
					var v = d[attr];
					if (v !== undefined && v !== null && v !== "") url += "&" + k + "=" + encodeURIComponent(v);
				});
				return url;
			}

			function activate(term) {
				buttons.forEach(function(b) {
					b.classList.toggle("active", b.getAttribute("data-term") === term);
				});
				wrapper.querySelectorAll(".tcf-courses-grid").forEach(function(g) {
					var m = term === "all"
						? g.classList.contains("tcf-all")
						: g.classList.contains("tcf-" + term);
					g.classList.toggle("active", m);
				});
			}

			function skeletonHtml(count) {
				count = count || 3;
				var cards = "";
				for (var i = 0; i < count; i++) {
					cards +=
						'<div class="tcf-skeleton-card">' +
							'<div class="tcf-skeleton-thumb"></div>' +
							'<div class="tcf-skeleton-body">' +
								'<div class="tcf-skeleton-line title"></div>' +
								'<div class="tcf-skeleton-line short"></div>' +
								'<div class="tcf-skeleton-line short"></div>' +
								'<div class="tcf-skeleton-line btn"></div>' +
							'</div>' +
						'</div>';
				}
				return '<div class="tcf-skeleton-row">' + cards + '</div>';
			}

			function loadTerm(term) {
				if (lists.querySelector(".tcf-courses-grid.tcf-" + term)) {
					activate(term);
					return;
				}
				if (loading) return;
				loading = term;

				var skelShown = false;
				var skel = null;

				// Short delay to avoid skeleton flash on fast connections
				var timer = setTimeout(function() {
					if (skelShown) return;
					skelShown = true;
					skel = document.createElement("div");
					skel.className = "tcf-courses-grid tcf-" + term + " active tcf-is-skeleton";
					skel.setAttribute("data-tcf-page", "1");
					skel.innerHTML = skeletonHtml(parseInt(wrapper.dataset.tcfPerpage, 10) || 3);
					lists.insertBefore(skel, lists.firstChild);

					wrapper.querySelectorAll(".tcf-courses-grid").forEach(function(g) {
						if (g !== skel) g.classList.remove("active");
					});
				}, 250);

				fetch(buildUrl(term))
					.then(function(r) { return r.json(); })
					.then(function(data) {
						clearTimeout(timer);
						if (data && data.html) {
							if (!skelShown) {
								skel = document.createElement("div");
								skel.className = "tcf-courses-grid tcf-" + term;
								skel.setAttribute("data-tcf-page", "1");
								skel.innerHTML = data.html;
								lists.insertBefore(skel, lists.firstChild);
							} else {
								skel.classList.remove("tcf-is-skeleton");
								skel.innerHTML = data.html;
							}
							activate(term);
						} else if (skel) {
							skel.remove();
						}
					})
					.catch(function() { clearTimeout(timer); if (skel) { skel.remove(); } })
					.finally(function() { loading = null; });
			}

			function loadMore(term, btn) {
				if (loading) return;
				loading = term;

				var grid = lists.querySelector(".tcf-courses-grid.tcf-" + term);
				if (!grid) { loading = null; return; }

				var page = (parseInt(grid.getAttribute("data-tcf-page"), 10) || 1) + 1;
				var moreWrap = grid.querySelector(".tcf-more-wrap");
				var label = "Load more";
				if (btn) { label = btn.textContent; btn.disabled = true; btn.textContent = "..."; }

				fetch(buildUrl(term) + "&page=" + page)
					.then(function(r) { return r.json(); })
					.then(function(data) {
						if (data && data.html && !(data.html.indexOf("tcf-row") === -1 && !data.hasMore)) {
							var tmp = document.createElement("div");
							tmp.innerHTML = data.html;
							while (tmp.firstChild) {
								grid.insertBefore(tmp.firstChild, moreWrap || null);
							}
							grid.setAttribute("data-tcf-page", page);
							if (!data.hasMore && moreWrap) { moreWrap.remove(); return; }
							if (btn) { btn.disabled = false; btn.textContent = label; }
						} else {
							if (moreWrap) moreWrap.remove();
						}
					})
					.catch(function() { if (btn) { btn.disabled = false; btn.textContent = label; } })
					.finally(function() { loading = null; });
			}

			var current = null;
			buttons.forEach(function(b) { if (b.classList.contains("active")) current = b.getAttribute("data-term"); });
			if (!current && buttons.length > 0) current = buttons[0].getAttribute("data-term");
			if (current) activate(current);

			wrapper.addEventListener("click", function(e) {
				var lm = e.target.closest(".tcf-load-more-btn");
				if (lm) {
					e.preventDefault();
					var gridEl = lm.closest(".tcf-courses-grid");
					var term = "all";
					if (gridEl && !gridEl.classList.contains("tcf-all")) {
						var m = gridEl.className.match(/tcf-term-(\d+)/);
						if (m) term = "term-" + m[1];
					}
					loadMore(term, lm);
					return;
				}
				var btn = e.target.closest(".tcf-btn");
				if (!btn) return;
				e.preventDefault();
				var term = btn.getAttribute("data-term");
				if (!term) return;
				if (term === "all" || lists.querySelector(".tcf-courses-grid.tcf-" + term)) {
					activate(term);
				} else {
					loadTerm(term);
				}
			});
		});
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", initTCF);
	} else {
		initTCF();
	}
	setTimeout(initTCF, 400);
	setTimeout(initTCF, 1200);

	if (document.body.classList.contains("block-editor-page") && typeof MutationObserver !== "undefined") {
		var observer = new MutationObserver(function() {
			setTimeout(initTCF, 200);
		});
		observer.observe(document.body, { childList: true, subtree: true });
	}
})();

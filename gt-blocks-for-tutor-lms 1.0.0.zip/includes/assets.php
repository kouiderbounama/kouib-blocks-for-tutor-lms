<?php
/**
 * Block asset registration (registered on init).
 *
 * - CSS (tcf-style): registered as a handle and referenced from block.json via
 *   the `style` property, so it loads automatically on the frontend only when
 *   the block exists, and in the editor too.
 * - Frontend script (tcf-view): registered as a handle and referenced from
 *   block.json via the `viewScript` property, so it loads automatically on the
 *   frontend only when the block exists. In the editor we load it through
 *   enqueue_block_editor_assets so the filter buttons work in the
 *   ServerSideRender preview.
 *
 * Important timing note: WordPress starts loading block assets (style/viewScript)
 * from block.json inside WP_Block::render() before render_callback runs, so
 * late registration (inside the callback) leaves the handles unavailable and
 * they never load. Solution: register the assets early, on the init hook.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcf_register_assets() {
	if ( ! wp_style_is( 'tcf-style', 'registered' ) ) {
		wp_register_style( 'tcf-style', TCF_URL . 'assets/css/tcf.css', array(), TCF_VERSION );
	}

	if ( ! wp_script_is( 'tcf-view', 'registered' ) ) {
		wp_register_script( 'tcf-view', TCF_URL . 'assets/js/view.js', array(), TCF_VERSION, true );
	}

	// Carousel block assets
	if ( ! wp_style_is( 'tcf-carousel-style', 'registered' ) ) {
		wp_register_style( 'tcf-carousel-style', TCF_URL . 'assets/css/tcf-carousel.css', array(), TCF_VERSION );
	}

	if ( ! wp_script_is( 'tcf-carousel-view', 'registered' ) ) {
		wp_register_script( 'tcf-carousel-view', TCF_URL . 'assets/js/carousel.js', array(), TCF_VERSION, true );
	}

	// Categories grid block assets
	if ( ! wp_style_is( 'tcf-categories-style', 'registered' ) ) {
		wp_register_style( 'tcf-categories-style', TCF_URL . 'assets/css/tcf-categories.css', array(), TCF_VERSION );
	}

	// Quick search block assets
	if ( ! wp_style_is( 'tcf-search-style', 'registered' ) ) {
		wp_register_style( 'tcf-search-style', TCF_URL . 'assets/css/tcf-search.css', array(), TCF_VERSION );
	}

	if ( ! wp_script_is( 'tcf-search-view', 'registered' ) ) {
		wp_register_script( 'tcf-search-view', TCF_URL . 'assets/js/search.js', array(), TCF_VERSION, true );
	}

	// Platform stats block assets (CSS only — no JavaScript in the first release)
	if ( ! wp_style_is( 'tcf-stats-style', 'registered' ) ) {
		wp_register_style( 'tcf-stats-style', TCF_URL . 'assets/css/tcf-stats.css', array(), TCF_VERSION );
	}
}
add_action( 'init', 'tcf_register_assets' );

/**
 * Register translation sources for the block editor scripts (tcf/* blocks).
 *
 * Runs after init (priority 20) so the editor script handles registered by
 * register_block_type_from_metadata already exist. The Arabic editor strings
 * are stored in a generated PHP array (includes/editor-i18n.php) and handed to
 * wp.i18n.setLocaleData() through the pre_load_script_translations filter, so
 * no .json translation files are shipped in the languages folder. Calling
 * wp_set_script_translations() here is what triggers load_script_textdomain(),
 * which fires that filter for each editor handle.
 */
function tcf_set_script_translations() {
	$languages = trailingslashit( dirname( __DIR__ ) ) . 'languages';
	$handles = array(
		'tcf-courses-filter-editor-script',
		'tcf-courses-carousel-editor-script',
		'tcf-courses-categories-editor-script',
		'tcf-courses-search-editor-script',
		'tcf-courses-stats-editor-script',
	);

	foreach ( $handles as $handle ) {
		wp_set_script_translations( $handle, 'gt-blocks-for-tutor-lms', $languages );
	}
}
add_action( 'init', 'tcf_set_script_translations', 20 );

/**
 * Supplies the Arabic editor translations for the tcf/* block scripts through
 * the pre_load_script_translations filter, before WordPress tries to read any
 * translation file. This replaces the JSON JED files that used to live in the
 * languages folder. The returned value must be JSON already encoded with the
 * flat JED shape wp.i18n.setLocaleData() expects: { "": {domain, lang,
 * plural-forms}, "msgid": ["translation"], ... }.
 */
function tcf_pre_load_script_translations( $translations, $file, $slug, $domain ) {
	if ( 'gt-blocks-for-tutor-lms' !== $domain || 'ar' !== get_locale() ) {
		return $translations;
	}

	$blocks = array(
		'tcf-courses-filter-editor-script'      => 'courses-filter',
		'tcf-courses-carousel-editor-script'    => 'courses-carousel',
		'tcf-courses-categories-editor-script'  => 'courses-categories',
		'tcf-courses-search-editor-script'      => 'courses-search',
		'tcf-courses-stats-editor-script'       => 'courses-stats',
	);

	$block = isset( $blocks[ $slug ] ) ? $blocks[ $slug ] : '';

	if ( '' === $block ) {
		return $translations;
	}

	$all = tcf_editor_i18n();
	if ( ! isset( $all[ $block ] ) ) {
		return $translations;
	}

	return wp_json_encode( $all[ $block ] );
}
add_filter(
	'pre_load_script_translations',
	'tcf_pre_load_script_translations',
	10,
	4
);

/**
 * Ensures frontend assets (style + viewScript) load even on paths where the
 * automatic loading from block.json does not kick in. Called from render_callback.
 *
 * Each block loads only its own assets: 'filter' loads the filter CSS + the
 * filtering script, and 'carousel' loads the carousel CSS + its script instead
 * of loading everything on every page. (The base tcf-style CSS is required for
 * both because it carries the course card styles.)
 */
function tcf_enqueue_frontend_assets( $which = 'all' ) {
	if ( 'filter' === $which ) {
		wp_enqueue_style( 'tcf-style' );
		wp_enqueue_script( 'tcf-view' );
		return;
	}

	if ( 'carousel' === $which ) {
		wp_enqueue_style( 'tcf-style' );
		wp_enqueue_style( 'tcf-carousel-style' );
		wp_enqueue_script( 'tcf-carousel-view' );
		return;
	}

	if ( 'search' === $which ) {
		wp_enqueue_style( 'tcf-search-style' );
		wp_enqueue_script( 'tcf-search-view' );
		return;
	}

	if ( 'categories' === $which ) {
		wp_enqueue_style( 'tcf-categories-style' );
		return;
	}

	if ( 'stats' === $which ) {
		wp_enqueue_style( 'tcf-stats-style' );
		return;
	}

	wp_enqueue_style( 'tcf-style' );
	wp_enqueue_style( 'tcf-carousel-style' );
	wp_enqueue_script( 'tcf-view' );
	wp_enqueue_script( 'tcf-carousel-view' );
}

/**
 * Loads the filtering script in the editor (with a ServerSideRender preview) so
 * the category buttons respond inside the editor's iframe. The code uses a
 * MutationObserver to reinitialize when the preview re-renders.
 */
function tcf_enqueue_editor_assets() {
	tcf_register_assets();
	wp_enqueue_script( 'tcf-view' );
	wp_enqueue_script( 'tcf-carousel-view' );
	wp_enqueue_style( 'tcf-carousel-style' );
	wp_enqueue_style( 'tcf-categories-style' );
	wp_enqueue_style( 'tcf-search-style' );
	wp_enqueue_style( 'tcf-stats-style' );
}
add_action( 'enqueue_block_editor_assets', 'tcf_enqueue_editor_assets' );

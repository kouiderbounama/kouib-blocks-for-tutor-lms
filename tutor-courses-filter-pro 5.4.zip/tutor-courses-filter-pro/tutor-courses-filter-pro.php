<?php
/**
 * Plugin Name: Tutor LMS Courses Filter Pro
 * Description: بلوكا جوتنبرج لدورات Tutor LMS - فلتر بالتصنيفات (ترتيب حسب عدد الطلاب) وكاروسيل تفاعلي - متوافق مع Kadence وtheme.json
 * Version:     5.4.0
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Author:      kb
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: tutor-courses-filter-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TCF_META_STUDENTS', '_tcf_students_count' );
define( 'TCF_VERSION', '5.4.0' );
define( 'TCF_CACHE_KEYS_OPTION', 'tcf_active_cache_keys' );
define( 'TCF_URL', trailingslashit( plugin_dir_url( __FILE__ ) ) );

require_once __DIR__ . '/includes/cache.php';
require_once __DIR__ . '/includes/meta.php';
require_once __DIR__ . '/includes/assets.php';
require_once __DIR__ . '/includes/render.php';
require_once __DIR__ . '/includes/carousel-render.php';
require_once __DIR__ . '/includes/categories-render.php';
require_once __DIR__ . '/includes/rest.php';

/* ==========================================================================
 * 1. تحميل الترجمة
 * ========================================================================== */
function tcf_load_textdomain() {
	load_plugin_textdomain(
		'tutor-courses-filter-pro',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages'
	);
}
add_action( 'init', 'tcf_load_textdomain' );

/* ==========================================================================
 * 2. تسجيل البلوكات من block.json (المعيار الحديث للجوتنبرج)
 * ========================================================================== */
function tcf_register_block() {
	// البلوك 1: فلتر الدورات
	register_block_type_from_metadata(
		__DIR__ . '/build/courses-filter',
		array(
			'render_callback' => 'tcf_render_courses_filter',
		)
	);

	// البلوك 2: كاروسيل الدورات
	register_block_type_from_metadata(
		__DIR__ . '/build/courses-carousel',
		array(
			'render_callback' => 'tcf_render_courses_carousel',
		)
	);

	// البلوك 3: مربعات تصنيفات الدورات
	register_block_type_from_metadata(
		__DIR__ . '/build/courses-categories',
		array(
			'render_callback' => 'tcf_render_courses_categories',
		)
	);

	// ربط ملفات ترجمة سكريبت المحرر (JSON/JED) — الـ handle يتولد تلقائياً
	// بصيغة {اسم-البلوك}-editor-script عند التسجيل من metadata.
	$editor_handle = 'tcf-courses-filter-editor-script';
	if ( wp_script_is( $editor_handle, 'registered' ) ) {
		wp_set_script_translations( $editor_handle, 'tutor-courses-filter-pro', plugin_dir_path( __FILE__ ) . 'languages' );
	}

	$carousel_editor_handle = 'tcf-courses-carousel-editor-script';
	if ( wp_script_is( $carousel_editor_handle, 'registered' ) ) {
		wp_set_script_translations( $carousel_editor_handle, 'tutor-courses-filter-pro', plugin_dir_path( __FILE__ ) . 'languages' );
	}

	$categories_editor_handle = 'tcf-courses-categories-editor-script';
	if ( wp_script_is( $categories_editor_handle, 'registered' ) ) {
		wp_set_script_translations( $categories_editor_handle, 'tutor-courses-filter-pro', plugin_dir_path( __FILE__ ) . 'languages' );
	}
}
add_action( 'init', 'tcf_register_block' );

/* ==========================================================================
 * 3. التفعيل / إلغاء التثبيت
 * ========================================================================== */
register_activation_hook( __FILE__, 'tcf_activate_plugin_sync' );

function tcf_uninstall_plugin() {
	tcf_flush_courses_cache();
	delete_option( TCF_CACHE_KEYS_OPTION );
}
register_uninstall_hook( __FILE__, 'tcf_uninstall_plugin' );

/* ==========================================================================
 * 4. تفريغ الكاش تلقائياً عند تحديث الإضافة
 *
 * عند تغيّر إصدار الإضافة نُفرّغ كل نسخ الكاش المخزّنة، حتى لا تُخدَم الصفحات
 * بـ HTML قديم (مثل زر التسجيل قبل إصلاحه) رغم تحديث الكود.
 * ========================================================================== */
function tcf_maybe_upgrade() {
	$stored = get_option( 'tcf_version', '' );
	if ( $stored !== TCF_VERSION ) {
		tcf_flush_courses_cache();
		update_option( 'tcf_version', TCF_VERSION, false );
	}
}
add_action( 'init', 'tcf_maybe_upgrade' );

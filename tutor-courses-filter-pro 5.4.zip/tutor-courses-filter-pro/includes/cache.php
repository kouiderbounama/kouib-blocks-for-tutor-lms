<?php
/**
 * طبقة الكاش (Transient).
 *
 * تخزين ناتج HTML النهائي لكل تركيبة إعدادات، مع سجل بالمفاتيح النشطة
 * يسمح بحذفها كلها دفعة واحدة بدون LIKE على جدول wp_options.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * مدة صلاحية كاش HTML الافتراضية. قُصِّرت من ساعة إلى 30 دقيقة كشبكة أمان
 * إضافية ضد عدم إبطال الكاش عند تغيّر بيانات لا نملك hook مؤكداً لها
 * (مثل تحديث تقييم دورة). يمكن تعديلها عبر الفلتر:
 * add_filter( 'tcf_cache_ttl', fn() => 10 * MINUTE_IN_SECONDS );
 */
function tcf_get_cache_ttl() {
	return (int) apply_filters( 'tcf_cache_ttl', 30 * MINUTE_IN_SECONDS );
}

/**
 * يرجّع قائمة المفاتيح النشطة (يُحمَّل مرة واحدة فقط لكل طلب صفحة).
 */
function tcf_get_active_keys() {
	static $active_keys = null;
	if ( null === $active_keys ) {
		$active_keys = get_option( TCF_CACHE_KEYS_OPTION, array() );
		if ( ! is_array( $active_keys ) ) {
			$active_keys = array();
		}
	}
	return $active_keys;
}

/**
 * يقلّم المفاتيح المنتهية صلاحيتها (مفاتيح الـ Transient لم تعد موجودة) كي لا
 * ينمو الخيار بلا حدود مع تنوّع تركيبات attributes أو التصنيفات.
 *
 * بدل فحص القائمة كاملة (التي قد تصل لمئات المفاتيح) في طلب واحد، يفحص
 * شريحة محدودة فقط (30) ويحذف منها المنتهي — الحمل موزّع على الطلبات
 * ولا يتحوّل إلى دفعة من استعلامات متكررة. نفّذ التقليم فقط عند تجاوز حد 150.
 */
function tcf_prune_active_keys( $active_keys ) {
	if ( count( $active_keys ) < 150 ) {
		return $active_keys;
	}

	$sample = array_slice( $active_keys, 0, 30 );
	$dead   = array();
	foreach ( $sample as $k ) {
		if ( false === get_transient( $k ) ) {
			$dead[] = $k;
		}
	}

	if ( empty( $dead ) ) {
		return $active_keys;
	}

	$fresh = array();
	foreach ( $active_keys as $k ) {
		if ( ! in_array( $k, $dead, true ) ) {
			$fresh[] = $k;
		}
	}
	update_option( TCF_CACHE_KEYS_OPTION, $fresh, false );
	return $fresh;
}

/**
 * يرجّع مفتاح كاش (HTML/cat) ويسجّله في قائمة المفاتيح النشطة عشان نقدر
 * نحذفهم كلهم لاحقاً، مع التقليم الدوري للمفاتيح المنتهية.
 */
function tcf_register_active_key( $key ) {
	$active_keys = tcf_get_active_keys();
	if ( ! in_array( $key, $active_keys, true ) ) {
		$active_keys = tcf_prune_active_keys( $active_keys );
		$active_keys[] = $key;
		update_option( TCF_CACHE_KEYS_OPTION, $active_keys, false );
	}
}

/**
 * يرجّع مفتاح الكاش الخاص بتركيبة attributes معينة (للصفحة الكاملة).
 *
 * المفتاح يتضمّن إصدار الإضافة عمداً: عند تحديث الكود يتغيّر المفتاح فيُعرض
 * HTML طازج فوراً بدل محتوى قديم من الكاش القديم.
 */
function tcf_get_cache_key( $attributes ) {
	ksort( $attributes );
	$key = 'tcf_html_' . TCF_VERSION . '_' . md5( wp_json_encode( $attributes ) );
	tcf_register_active_key( $key );
	return $key;
}

/**
 * تفريغ كل نسخ الكاش المخزّنة (يُستدعى عند أي تغيير يؤثر على مخرجات البلوك).
 *
 * حراسة static: بعض الأحداث تُطلق أكثر من hook متشابه للحدث نفسه
 * (تسجيل الطالب مثلاً يُطلق 3 أسماء hooks)، فنُفرّغ مرة واحدة فقط لكل طلب
 * بدل تكرار نفس حذف الـ transients 3 مرات (3 × عدد المفاتيح استعلامَات).
 */
function tcf_flush_courses_cache() {
	static $flushed = false;
	if ( $flushed ) {
		return;
	}
	$flushed = true;

	$active_keys = get_option( TCF_CACHE_KEYS_OPTION, array() );
	if ( is_array( $active_keys ) ) {
		foreach ( $active_keys as $key ) {
			delete_transient( $key );
		}
	}
	update_option( TCF_CACHE_KEYS_OPTION, array(), false );
}

// إبطال الكاش عند أي تغيير في بيانات الدورات ذات الصلة
add_action( 'save_post_courses', 'tcf_flush_courses_cache', 30 );
add_action( 'deleted_post', function( $post_id ) {
	// حذف أي منشور آخر (صفحة/منتج...) لا يُفرّغ كاش الدورات عبثاً
	if ( get_post_type( $post_id ) === 'courses' ) {
		tcf_flush_courses_cache();
	}
}, 30 );
add_action( 'tcf_delayed_students_update', 'tcf_flush_courses_cache', 30 );
add_action( 'tutor_after_enrolled', 'tcf_flush_courses_cache', 30 );
add_action( 'tutor_after_enrollment', 'tcf_flush_courses_cache', 30 );
add_action( 'tutor_after_enroll', 'tcf_flush_courses_cache', 30 );
add_action( 'edited_course-category', 'tcf_flush_courses_cache' );
add_action( 'create_course-category', 'tcf_flush_courses_cache' );
add_action( 'delete_course-category', 'tcf_flush_courses_cache' );

// محاولات احتياطية لتفريغ الكاش عند تحديث تقييم دورة — أسماء الـ hooks
// تختلف بين نسخ Tutor LMS، والشبكة الحقيقية للأمان تبقى TTL الكاش.
add_action( 'tutor_after_rating_save', 'tcf_flush_courses_cache', 30 );
add_action( 'tutor_rating_saved', 'tcf_flush_courses_cache', 30 );

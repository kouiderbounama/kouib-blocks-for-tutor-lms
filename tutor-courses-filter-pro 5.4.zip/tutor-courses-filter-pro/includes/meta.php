<?php
/**
 * مزامنة عدد الطلاب لكل دورة في meta مخصص (_tcf_students_count)
 * ليمكن استخدامها في ORDER BY بدون استعلامات ثقيلة.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcf_normalize_post_id( $value ) {
	if ( is_object( $value ) && isset( $value->ID ) ) {
		return absint( $value->ID );
	}
	if ( is_array( $value ) && isset( $value['ID'] ) ) {
		return absint( $value['ID'] );
	}
	return absint( $value );
}

function tcf_update_course_students_meta( $course_id ) {
	$course_id = tcf_normalize_post_id( $course_id );

	if ( ! $course_id || ! function_exists( 'tutor_utils' ) ) {
		return;
	}
	if ( get_post_type( $course_id ) !== 'courses' ) {
		return;
	}

	// حراسة static: Event التسجيل الواحد يُطلق أكثر من hook متشابه +
	// save_post_tutor_enrolled — دونها يُعاد نفس استعلام العدّاد وتحديث meta حتى 4 مرات.
	static $updated = array();
	if ( isset( $updated[ $course_id ] ) ) {
		return;
	}
	$updated[ $course_id ] = true;

	$count = (int) tutor_utils()->count_enrolled_users_by_course( $course_id );
	update_post_meta( $course_id, TCF_META_STUDENTS, $count );
}

function tcf_ensure_students_meta( $post ) {
	// publish_courses تمرر كائن WP_Post وليس ID
	$post_id = tcf_normalize_post_id( $post );
	if ( ! $post_id || get_post_type( $post_id ) !== 'courses' ) {
		return;
	}
	if ( ! metadata_exists( 'post', $post_id, TCF_META_STUDENTS ) ) {
		update_post_meta( $post_id, TCF_META_STUDENTS, 0 );
	}
}
add_action( 'save_post_courses', 'tcf_ensure_students_meta', 20 );
add_action( 'publish_courses', 'tcf_ensure_students_meta', 20 );

add_action( 'tutor_after_enrolled', 'tcf_update_course_students_meta', 10, 1 );
add_action( 'tutor_after_enrollment', 'tcf_update_course_students_meta', 10, 1 );
add_action( 'tutor_after_enroll', 'tcf_update_course_students_meta', 10, 1 );

// حفظ سجل تسجيل طالب (tutor_enrolled) → تحديث عدّاد الدورة الأب
add_action( 'save_post_tutor_enrolled', function( $post_id ) {
	$course_id = wp_get_post_parent_id( $post_id );
	if ( $course_id ) {
		tcf_update_course_students_meta( $course_id );
	}
}, 20 );

// حذف سجل تسجيل → تحديث مؤجل بعد اكتمال عملية الحذف
add_action( 'before_delete_post', function( $post_id ) {
	if ( get_post_type( $post_id ) === 'tutor_enrolled' ) {
		$course_id = wp_get_post_parent_id( $post_id );
		if ( $course_id ) {
			wp_schedule_single_event( time() + 3, 'tcf_delayed_students_update', array( $course_id ) );
		}
	}
} );
add_action( 'tcf_delayed_students_update', 'tcf_update_course_students_meta' );

/**
 * مزامنة كل الدورات — تُستدعى عند تفعيل الإضافة.
 *
 * التنفيذ في الخلفية على دفعات (100 دورة لكل حدث مجدول) عبر
 * wp-cron بدل حلقة ضخمة تبطل استجابة التفعيل على المواقع الكبيرة.
 */
function tcf_activate_plugin_sync() {
	if ( function_exists( 'tutor_utils' ) && ! wp_next_scheduled( 'tcf_sync_students_batch' ) ) {
		wp_schedule_single_event( time() + 5, 'tcf_sync_students_batch', array( 0 ) );
	}
}

function tcf_sync_students_batch_cb( $offset ) {
	$offset  = max( 0, (int) $offset );
	$batch   = 100;
	$courses = get_posts( array(
		'post_type'      => 'courses',
		'post_status'    => 'any',
		'posts_per_page' => $batch,
		'fields'         => 'ids',
		'offset'         => $offset,
		'no_found_rows'  => true,
	) );

	foreach ( $courses as $course_id ) {
		tcf_update_course_students_meta( $course_id );
	}

	if ( count( $courses ) === $batch ) {
		wp_schedule_single_event( time() + 5, 'tcf_sync_students_batch', array( $offset + $batch ) );
	}
}
add_action( 'tcf_sync_students_batch', 'tcf_sync_students_batch_cb' );

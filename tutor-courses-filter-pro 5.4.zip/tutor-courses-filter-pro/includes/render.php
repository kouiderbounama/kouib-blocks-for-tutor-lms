<?php
/**
 * منطق الرندر: استعلام واحد + تجميع حسب التصنيف، الكاش، وسكريبت الفلترة.
 *
 * تحسين الأداء (v4.1.0):
 * - في الواجهة الأمامية لا تُخصَّر كل التصنيفات في HTML دفعة واحدة؛ بل يُعرض
 *   الشبكة النشطة فقط، وتُحمَّل باقي التصنيفات عند النقر عبر REST endpoint
 *   (مع كاش لكل تصنيف). هذا يقلّل حجم الصفحة والصور المحمَّلة مسبقاً.
 * - في المحرر (ServerSideRender) تُعرض كل التصنيفات كمعاينة كاملة.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ==========================================================================
 * 1. جلب الدورات باستعلام واحد وتجميعها حسب التصنيف (حل مشكلة N+1)
 * ========================================================================== */

/**
 * ينفّذ استعلام الدورات المجمّع فعلياً (دون كاش).
 *
 * استعلامان خفيفان فقط (v5.3.9): جلب معرّفات كل الدورات المتطابقة، وقراءة
 * علاقاتها مع تصنيفات course-category. لا وجود لأي جلب كائنات كاملة —
 * تُعاد المصفوفتان كمُعرّفات:
 *   'all'     => كل معرّفات الدورات بترتيبها
 *   'by_term' => term_id => المصيرفات بترتيبها
 * ومن ثم تجلب صفحة العرض فقط كائناتها عبر tcf_get_posts_by_ids() عند الرندر.
 * هذا يجعل الكاش صغيراً جداً ويزيل استعلامات الـ post__in الضخمة عن المواقع الكبيرة.
 */
function tcf_run_grouped_query( $query_args ) {

	$ids_args                   = $query_args;
	$ids_args['posts_per_page'] = -1;
	$ids_args['fields']         = 'ids';

	$all_ids = get_posts( $ids_args );

	$result = array( 'all' => array(), 'by_term' => array() );

	if ( empty( $all_ids ) ) {
		return $result;
	}

	$term_map      = array();
	$relationships = wp_get_object_terms(
		$all_ids,
		'course-category',
		array( 'fields' => 'all_with_object_id' )
	);

	if ( ! is_wp_error( $relationships ) ) {
		foreach ( $relationships as $rel ) {
			$cid = (int) $rel->object_id;
			if ( ! isset( $term_map[ $cid ] ) ) {
				$term_map[ $cid ] = array();
			}
			$term_map[ $cid ][] = (int) $rel->term_id;
		}
	}

	$all_ids = array_values( array_map( 'absint', $all_ids ) );
	$result['all'] = $all_ids;

	foreach ( $all_ids as $cid ) {
		if ( ! empty( $term_map[ $cid ] ) ) {
			foreach ( $term_map[ $cid ] as $tid ) {
				if ( ! isset( $result['by_term'][ $tid ] ) ) {
					$result['by_term'][ $tid ] = array();
				}
				$result['by_term'][ $tid ][] = $cid;
			}
		}
	}

	return $result;
}

/**
 * يُعيد كائنات المنشورات بترتيب $ids تماماً، باستعلام post__in واحد مُقيَّد
 * بعددها بدل تحميل القائمة كاملة في استعلام ضخم.
 */
function tcf_get_posts_by_ids( $ids ) {
	$ids = array_map( 'absint', (array) $ids );
	$ids = array_values( array_filter( $ids ) );
	if ( empty( $ids ) ) {
		return array();
	}

	$posts = get_posts( array(
		'post_type'      => 'courses',
		'post__in'       => $ids,
		'posts_per_page' => -1,
		'post_status'    => 'publish',
		'orderby'        => 'post__in',
		'no_found_rows'  => true,
	) );

	if ( empty( $posts ) ) {
		return array();
	}

	$by_id = array();
	foreach ( $posts as $p ) {
		$by_id[ $p->ID ] = $p;
	}

	$ordered = array();
	foreach ( $ids as $id ) {
		if ( isset( $by_id[ $id ] ) ) {
			$ordered[] = $by_id[ $id ];
		}
	}
	return $ordered;
}

/**
 * يجلب عدداً محدوداً من الدورات مطابقاً للترتيب المطلوب باستعلام مُقيَّد
 * (بدون تحميل القائمة كاملة) — تُستخدم في الكاروسيل وبقية المواضع التي تحتاج
 * صفحة أولى فقط. يحترم tax_query والترتيب المخصص.
 */
function tcf_get_courses_bounded( $query_args, $limit ) {
	$limit = max( 1, (int) $limit );

	$ids_args = $query_args;
	$ids_args['posts_per_page'] = $limit;
	$ids_args['fields']         = 'ids';
	$ids_args['no_found_rows']  = true;

	$ids = get_posts( $ids_args );
	if ( empty( $ids ) ) {
		return array();
	}

	return tcf_get_posts_by_ids( $ids );
}

/**
 * يجيب كل الدورات المطابقة لمعايير $query_args (بدون حد أقصى) مع كاش للاستعلام
 * المجمّع (غير العشوائي) لتخفيف الحمل عند تكرار الطلبات عبر REST أو عند تجاهل
 * كاش الشبكات (مثل تغيّر بارامترات). يُسجَّل المفتاح كمفتاح نشط فيُمسح تلقائياً
 * مع دواعم إبطال الكاش (حفظ دورة/تعديل تصنيف/تسجيل/تقييم).
 *
 * الترتيب العشوائي (rand) يُخزَّن الآن بمدة قصيرة جداً (60 ثانية افتراضياً عبر
 * فلتر tcf_rand_cache_ttl) — كي لا يُعاد استعلام مجمّع ثقيل مع كل زيارة، مع بقاء
 * درجة كافية من الطزاجة.
 */
function tcf_get_grouped_courses( $query_args ) {
	$orderby = isset( $query_args['orderby'] ) ? $query_args['orderby'] : 'date';

	if ( 'rand' === $orderby ) {
		$cache_key = 'tcf_grp_' . TCF_VERSION . '_rand_' . md5( wp_json_encode( $query_args ) );
		tcf_register_active_key( $cache_key );

		$cached = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		$result = tcf_run_grouped_query( $query_args );
		set_transient( $cache_key, $result, (int) apply_filters( 'tcf_rand_cache_ttl', MINUTE_IN_SECONDS ) );
		return $result;
	}

	$cache_bits = array( 'orderby' => $orderby );
	if ( isset( $query_args['order'] ) ) {
		$cache_bits['order'] = $query_args['order'];
	}
	if ( isset( $query_args['meta_key'] ) ) {
		$cache_bits['meta_key'] = $query_args['meta_key'];
	}
	if ( isset( $query_args['tax_query'] ) ) {
		$cache_bits['tax_query'] = $query_args['tax_query'];
	}
	ksort( $cache_bits );
	$cache_key = 'tcf_grp_' . TCF_VERSION . '_' . md5( wp_json_encode( $cache_bits ) );
	tcf_register_active_key( $cache_key );

	$cached = get_transient( $cache_key );
	if ( false !== $cached ) {
		return $cached;
	}

	$result = tcf_run_grouped_query( $query_args );
	set_transient( $cache_key, $result, tcf_get_cache_ttl() );

	return $result;
}

/**
 * يبني query_args حسب خيار الترتيب المطلوب، وعند تمرير تصنيفات يُقيّد عليها
 * (تستخدمها شبكة الفلتر والكاروسيل معاً).
 */
function tcf_build_query_args( $orderby_attr, $category_ids = array() ) {
	$query_args = array(
		'post_type'     => 'courses',
		'post_status'   => 'publish',
		'no_found_rows' => true,
	);

	switch ( $orderby_attr ) {
		case 'date_asc':
			$query_args['orderby'] = 'date';
			$query_args['order']   = 'ASC';
			break;
		case 'title':
			$query_args['orderby'] = 'title';
			$query_args['order']   = 'ASC';
			break;
		case 'rand':
			$query_args['orderby'] = 'rand';
			break;
		case 'students':
			$query_args['meta_query'] = array(
				'relation' => 'OR',
				array(
					'key'     => TCF_META_STUDENTS,
					'compare' => 'EXISTS',
				),
				array(
					'key'     => TCF_META_STUDENTS,
					'compare' => 'NOT EXISTS',
				),
			);
			$query_args['orderby']  = 'meta_value_num';
			$query_args['meta_key'] = TCF_META_STUDENTS;
			$query_args['order']    = 'DESC';
			break;
		default:
			$query_args['orderby'] = 'date';
			$query_args['order']   = 'DESC';
	}

	$category_ids = array_map( 'absint', (array) $category_ids );
	$category_ids = array_values( array_filter( $category_ids ) );

	if ( ! empty( $category_ids ) ) {
		$query_args['tax_query'] = array(
			array(
				'taxonomy' => 'course-category',
				'field'    => 'term_id',
				'terms'    => $category_ids,
				'operator' => 'IN',
			),
		);
	}

	return $query_args;
}

/**
 * يعيد قائمة التصنيفات المرتبة (أو مصفوفة فارغة عند الخطأ).
 *
 * @param bool $hide_empty إخفاء التصنيفات بلا دورات (الافتراضي true).
 */
function tcf_get_terms_list( $hide_empty = true ) {
	$terms = get_terms( array(
		'taxonomy'   => 'course-category',
		'hide_empty' => (bool) $hide_empty,
		'orderby'    => 'name',
		'order'      => 'ASC',
		'number'     => 100,
	) );

	if ( is_wp_error( $terms ) ) {
		return array();
	}

	return $terms;
}

/* ==========================================================================
 * 2. دالة الرندر (render_callback)
 * ========================================================================== */
function tcf_render_courses_filter( $attributes ) {

	tcf_enqueue_frontend_assets( 'filter' );

	$orderby_attr = isset( $attributes['orderby'] ) ? $attributes['orderby'] : 'date';

	$is_editor_request = defined( 'REST_REQUEST' ) && REST_REQUEST;
	$use_cache         = ! $is_editor_request && ( 'rand' !== $orderby_attr );

	// الكاش: فحص مبكر قبل أي استعلام أو رسم — عند الإصابة نعيد HTML الصفحة كاملاً
	$cache_key = null;
	if ( $use_cache ) {
		$cache_key = tcf_get_cache_key( $attributes );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}
	}

	$per_page      = isset( $attributes['perPage'] ) ? max( 1, (int) $attributes['perPage'] ) : 3;
	$columns       = isset( $attributes['columns'] ) ? max( 1, min( 4, (int) $attributes['columns'] ) ) : 3;
	$show_all      = isset( $attributes['showAll'] ) ? (bool) $attributes['showAll'] : true;
	$show_level    = isset( $attributes['showLevel'] ) ? (bool) $attributes['showLevel'] : true;
	$show_rating   = isset( $attributes['showRating'] ) ? (bool) $attributes['showRating'] : true;
	$show_lessons  = isset( $attributes['showLessons'] ) ? (bool) $attributes['showLessons'] : true;
	$show_duration = isset( $attributes['showDuration'] ) ? (bool) $attributes['showDuration'] : true;
	$show_price    = isset( $attributes['showPrice'] ) ? (bool) $attributes['showPrice'] : true;
	$show_students = isset( $attributes['showStudents'] ) ? (bool) $attributes['showStudents'] : true;
	$show_enroll   = isset( $attributes['showEnrollBtn'] ) ? (bool) $attributes['showEnrollBtn'] : true;
	$enroll_btn_text = isset( $attributes['enrollBtnText'] ) ? sanitize_text_field( $attributes['enrollBtnText'] ) : '';
	if ( '' === $enroll_btn_text ) {
		$enroll_btn_text = __( 'تسجيل في الدورة', 'tutor-courses-filter-pro' );
	}
	$open_in_new_tab = ! empty( $attributes['openInNewTab'] );
	$primary_color = isset( $attributes['primaryColor'] ) ? $attributes['primaryColor'] : '#2a7be4';
	if ( ! preg_match( '/^#[0-9a-fA-F]{3,8}$/', $primary_color )
		&& ! preg_match( '/^rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*(,\s*[\d.]+\s*)?\)$/', $primary_color ) ) {
		$primary_color = '#2a7be4';
	}

	$terms = tcf_get_terms_list();

	if ( empty( $terms ) ) {
		return '<p style="text-align:center;padding:40px;color:#666;">' . esc_html__( 'لا توجد تصنيفات دورات متاحة حالياً.', 'tutor-courses-filter-pro' ) . '</p>';
	}

	// attrs النهائية لبناء الكاش ورندر التصنيفات (الكل → null، والتصنيفات → term objects)
	$render_attributes = array(
		'orderby'     => $orderby_attr,
		'perPage'     => $per_page,
		'showLevel'   => $show_level,
		'showRating'  => $show_rating,
		'showLessons' => $show_lessons,
		'showDuration'=> $show_duration,
		'showPrice'   => $show_price,
		'showStudents'=> $show_students,
		'showEnrollBtn'=> $show_enroll,
		'enrollBtnText'=> $enroll_btn_text,
		'openInNewTab'=> $open_in_new_tab,
	);

	$our_style = '--tcf-primary:' . esc_attr( $primary_color ) . ';--tcf-columns:' . absint( $columns ) . ';';

	// اتجاه الصفحة (يدعم RTL و LTR، بدلاً من فرض RTL دائماً)
	$direction = is_rtl() ? 'rtl' : 'ltr';
	$our_style .= 'direction:' . $direction . ';';

	if ( function_exists( 'get_block_wrapper_attributes' ) ) {
		$wrapper_attrs = get_block_wrapper_attributes( array(
			'class' => 'tutor-courses-filter-wrapper',
			'style' => $our_style,
		) );
	} else {
		$wrapper_attrs = sprintf(
			'class="tutor-courses-filter-wrapper" style="%s"',
			esc_attr( $our_style )
		);
	}

	// ملاحظة: get_block_wrapper_attributes() يتجاهل المفاتيح غير class/style
	// (عبر shortcode_atts)، لذلك نضيف dir والبيانات المخصصة يدوياً.
	$wrapper_attrs .= sprintf(
		' dir="%1$s" data-tcf-rest="%2$s" data-tcf-orderby="%3$s" data-tcf-perpage="%4$d" data-tcf-showlevel="%5$s" data-tcf-showrating="%6$s" data-tcf-showlessons="%7$s" data-tcf-showduration="%8$s" data-tcf-showprice="%9$s" data-tcf-showstudents="%10$s" data-tcf-showenrollbtn="%11$s" data-tcf-enrollbtntext="%12$s" data-tcf-openinnewtab="%13$s"',
		esc_attr( $direction ),
		esc_url( rest_url( 'tcf/v1/courses' ) ),
		esc_attr( $orderby_attr ),
		absint( $per_page ),
		$show_level ? '1' : '0',
		$show_rating ? '1' : '0',
		$show_lessons ? '1' : '0',
		$show_duration ? '1' : '0',
		$show_price ? '1' : '0',
		$show_students ? '1' : '0',
		$show_enroll ? '1' : '0',
		esc_attr( $enroll_btn_text ),
		$open_in_new_tab ? '1' : '0'
	);

	ob_start();
	?>
	<div <?php echo $wrapper_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- مُهربّة داخلياً ?>>
		<div class="tutor-courses-filter-buttons">
			<?php if ( $show_all ) : ?>
				<button type="button" class="tcf-btn <?php echo $show_all ? 'active' : ''; ?>" data-term="all"><?php echo esc_html__( 'الكل', 'tutor-courses-filter-pro' ); ?></button>
			<?php endif; ?>
			<?php foreach ( $terms as $index => $term ) : ?>
				<button type="button" class="tcf-btn <?php echo ( ! $show_all && $index === 0 ) ? 'active' : ''; ?>" data-term="term-<?php echo esc_attr( $term->term_id ); ?>">
					<?php echo esc_html( $term->name ); ?>
				</button>
			<?php endforeach; ?>
		</div>

		<div class="tutor-courses-filter-lists">
			<?php
			// التصنيف النشط افتراضياً (الكُل أو أول تصنيف)
			if ( $show_all ) {
				$active_term    = null;
				$active_class   = 'tcf-all active';
			} else {
				$first          = reset( $terms );
				$active_term    = $first;
				$active_class   = 'tcf-term-' . $first->term_id . ' active';
			}

			?>
			<?php if ( $is_editor_request ) : ?>
				<?php
				$query_args     = tcf_build_query_args( $render_attributes['orderby'] );
				$grouped        = tcf_get_grouped_courses( $query_args );
				$all_ids_l      = isset( $grouped['all'] ) ? $grouped['all'] : array();
				$all_sliced     = tcf_get_posts_by_ids( array_slice( $all_ids_l, 0, $per_page ) );
				?>
				<?php if ( $show_all ) : ?>
					<div class="tcf-courses-grid tcf-all active">
						<?php echo tcf_render_courses_from_posts( $all_sliced, $show_level, $show_rating, $show_lessons, $show_duration, $show_price, $show_students, $show_enroll, null, $enroll_btn_text, $open_in_new_tab ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
				<?php endif; ?>
				<?php foreach ( $terms as $index => $term ) :
					$term_ids          = isset( $grouped['by_term'][ $term->term_id ] ) ? $grouped['by_term'][ $term->term_id ] : array();
					$term_posts_sliced = tcf_get_posts_by_ids( array_slice( $term_ids, 0, $per_page ) );
					$is_first          = ( ! $show_all && $index === 0 );
					?>
					<div class="tcf-courses-grid tcf-term-<?php echo esc_attr( $term->term_id ); ?> <?php echo $is_first ? 'active' : ''; ?>">
						<?php echo tcf_render_courses_from_posts( $term_posts_sliced, $show_level, $show_rating, $show_lessons, $show_duration, $show_price, $show_students, $show_enroll, $term, $enroll_btn_text, $open_in_new_tab ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
				<?php endforeach; ?>
			<?php else : ?>
				<div class="tcf-courses-grid <?php echo esc_attr( $active_class ); ?>" data-tcf-page="1">
					<?php
					$active_grid = tcf_render_category_grid_html( $active_term, $render_attributes );
					echo $active_grid['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php
	$html = ob_get_clean();

	if ( $use_cache ) {
		set_transient( $cache_key, $html, tcf_get_cache_ttl() );
	}

	return $html;
}

/**
 * يرجع كل معرّفات دورات تصنيف معيّن (أو الكل عند null) مرتبة وفق $attributes —
 * مُعرّفات فقط (ناتجة من الاستعلام المجمّع المخزّن)، كي يبقى الكاش خفيفاً.
 * تُستخدم للترقيم (Load More): تُجلَب كائنات صفحة العرض فقط عند الرندر.
 */
function tcf_render_posts_for_term( $term, $attributes ) {
	$query_args = tcf_build_query_args( $attributes['orderby'] );
	$grouped    = tcf_get_grouped_courses( $query_args );

	if ( $term ) {
		return isset( $grouped['by_term'][ $term->term_id ] ) ? $grouped['by_term'][ $term->term_id ] : array();
	}
	return $grouped['all'];
}

/**
 * يرندِر صفحة (1-based) من شبكة تصنيف واحد (أو الكل عند null) مع كاش لكل صفحة.
 * يعيد مصفوفة: ['html' => HTML البطاقات (+زر تحميل المزيد في الصفحة الأولى),
 *              'has_more' => هل توجد صفحات تالية].
 * تُستخدم في الواجهة الأمامية للشبكة النشطة وفي REST endpoint.
 */
function tcf_render_category_grid_html( $term, $attributes, $page = 1 ) {
	$page     = max( 1, (int) $page );
	$per_page = max( 1, (int) $attributes['perPage'] );

	// الترتيب العشوائي لا يُخزَّن كي يبقى طازجاً ولتجنّب تحفّظ كاش راكد على ترتيب ثابت.
	$use_cache = ( isset( $attributes['orderby'] ) && 'rand' === $attributes['orderby'] ) ? false : true;

	$cache_bits = array( 'term' => $term ? (int) $term->term_id : 'all', 'page' => $page );
	if ( $use_cache ) {
		foreach ( array( 'orderby', 'perPage', 'showLevel', 'showRating', 'showLessons', 'showDuration', 'showPrice', 'showStudents', 'showEnrollBtn', 'enrollBtnText', 'openInNewTab' ) as $a ) {
			if ( isset( $attributes[ $a ] ) ) {
				$cache_bits[ $a ] = $attributes[ $a ];
			}
		}
		ksort( $cache_bits );
		$cache_key = 'tcf_catp_' . TCF_VERSION . '_' . md5( wp_json_encode( $cache_bits ) );
		tcf_register_active_key( $cache_key );

		$cached = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}
	}
	{
		$show_level    = ! empty( $attributes['showLevel'] );
		$show_rating   = ! empty( $attributes['showRating'] );
		$show_lessons  = ! empty( $attributes['showLessons'] );
		$show_duration = ! empty( $attributes['showDuration'] );
		$show_price    = ! empty( $attributes['showPrice'] );
		$show_students = ! empty( $attributes['showStudents'] );
		$show_enroll   = ! empty( $attributes['showEnrollBtn'] );
		$enroll_btn_text = isset( $attributes['enrollBtnText'] ) ? sanitize_text_field( $attributes['enrollBtnText'] ) : '';
		if ( '' === $enroll_btn_text ) {
			$enroll_btn_text = __( 'تسجيل في الدورة', 'tutor-courses-filter-pro' );
		}
		$open_in_new_tab = ! empty( $attributes['openInNewTab'] );

		$full   = tcf_render_posts_for_term( $term, $attributes );
		$offset = ( $page - 1 ) * $per_page;
		$ids    = array_slice( $full, $offset, $per_page );
		$has_more = count( $full ) > ( $offset + $per_page );

		// جلب كائنات الصفحة المعروضة فقط (لا القائمة الكاملة) — استعلام post__in
		// مقيّد بعدد البطاقات، آمن للمواقع الكبيرة.
		$posts = tcf_get_posts_by_ids( $ids );

		$html = tcf_render_courses_from_posts( $posts, $show_level, $show_rating, $show_lessons, $show_duration, $show_price, $show_students, $show_enroll, $term, $enroll_btn_text, $open_in_new_tab );

		if ( 1 === $page && $has_more ) {
			$html .= '<div class="tcf-more-wrap"><button type="button" class="tcf-load-more-btn">' . esc_html__( 'تحميل المزيد', 'tutor-courses-filter-pro' ) . '</button></div>';
		}

		$cached = array( 'html' => $html, 'has_more' => $has_more );
		if ( $use_cache ) {
			set_transient( $cache_key, $cached, tcf_get_cache_ttl() );
		}
	}

	return $cached;
}

/**
 * ملاحظة: سكربت الفلترة الأمامي انتقل إلى ملف مستقل (assets/js/view.js)
 * ويُحمَّل عبر viewScript في block.json على الواجهة، وعبر
 * enqueue_block_editor_assets في المحرر. لا حاجة لطباعة إسكريبت inline هنا.
 */

/* ==========================================================================
 * 3. رسم الكروت
 * ========================================================================== */

/**
 * يرجع نص سعر الدورة كنص بسيط (عربي/رقم) آمن للكاش، دون أي أزرار أو سكربتات
 * من Tutor. يعتمد على meta الخاصة بالدورة بدل استدعاءات الـ loop التفاعلية.
 */
function tcf_get_course_price_text( $course_id ) {
	$course_id = absint( $course_id );
	if ( ! $course_id ) {
		return '';
	}

	$price_type = (string) get_post_meta( $course_id, '_tutor_course_price_type', true );

	if ( 'free' === $price_type ) {
		return __( 'مجاني', 'tutor-courses-filter-pro' );
	}

	$raw = get_post_meta( $course_id, '_tutor_course_price', true );

	if ( ( '' === (string) $raw || null === $raw ) && function_exists( 'tutor_utils' ) && method_exists( tutor_utils(), 'get_course_price' ) ) {
		$price_obj = tutor_utils()->get_course_price( $course_id );
		if ( is_object( $price_obj ) ) {
			if ( isset( $price_obj->sale_price ) && $price_obj->sale_price ) {
				$raw = $price_obj->sale_price;
			} elseif ( isset( $price_obj->regular_price ) ) {
				$raw = $price_obj->regular_price;
			}
		}
	}

	$raw = trim( (string) $raw );
	if ( '' === $raw ) {
		return __( 'مجاني', 'tutor-courses-filter-pro' );
	}

	if ( is_numeric( $raw ) ) {
		return number_format_i18n( (float) $raw, 2 );
	}

	return esc_html( $raw );
}

/**
 * عدد الدروس للدورة — يُخفَّظ لكل دورة في نفس الطلب (عندما تظهر الدورة نفسها
 * في أكثر من تصنيف لا تتكرر استعلامات Tutor الثقيلة).
 */
function tcf_card_lesson_count( $course_id ) {
	static $counts = array();
	if ( ! array_key_exists( $course_id, $counts ) ) {
		$counts[ $course_id ] = function_exists( 'tutor_utils' )
			? (int) tutor_utils()->get_lesson_count_by_course( $course_id )
			: 0;
	}
	return $counts[ $course_id ];
}

/**
 * تقييم الدورة — حفظ مؤقت مماثل لكل دورة في نفس الطلب.
 */
function tcf_card_rating( $course_id ) {
	static $ratings = array();
	if ( ! array_key_exists( $course_id, $ratings ) ) {
		$ratings[ $course_id ] = function_exists( 'tutor_utils' )
			? tutor_utils()->get_course_rating( $course_id )
			: null;
	}
	return $ratings[ $course_id ];
}

/**
 * يرسم بطاقة دورة واحدة مستقلّة — مشتركة بين الفلتر والكاروسيل.
 */
function tcf_render_course_card( $post, $show_level, $show_rating, $show_lessons, $show_duration, $show_price, $show_students = true, $show_enroll = true, $enroll_btn_text = '', $open_in_new_tab = false ) {

	if ( '' === $enroll_btn_text ) {
		$enroll_btn_text = __( 'تسجيل في الدورة', 'tutor-courses-filter-pro' );
	}

	ob_start();
	setup_postdata( $post );
	$course_id = $post->ID;

	$level = '';
	if ( $show_level ) {
		$level = function_exists( 'get_tutor_course_level' ) ? get_tutor_course_level( $course_id ) : get_post_meta( $course_id, '_tutor_course_level', true );
	}

	$rating = null;
	if ( $show_rating ) {
		$rating = tcf_card_rating( $course_id );
	}

	$lessons = 0;
	if ( $show_lessons ) {
		$lessons = tcf_card_lesson_count( $course_id );
	}

	$duration = '';
	if ( $show_duration ) {
		$duration = function_exists( 'get_tutor_course_duration_context' ) ? wp_strip_all_tags( get_tutor_course_duration_context( $course_id ) ) : get_post_meta( $course_id, '_course_duration', true );
	}

	/*
	 * السعر: نعرضه كنص فقط (آمن للكاش) بدلاً من tutor_course_loop_price()
	 * التي تُخرج زر تسجيل تفاعلياً من Tutor يعتمد على سكربتات/حالة المستخدم
	 * ولا يعمل داخل الكاش ولا مع التحميل عبر REST (وينتج رابطاً يؤدّي للرئيسية).
	 */
	$price_html = '';
	$is_free    = false;
	if ( $show_price ) {
		$price_html = tcf_get_course_price_text( $course_id );
		$is_free    = ( 'free' === get_post_meta( $course_id, '_tutor_course_price_type', true ) );
	}

	// عدد الطلاب: بيانات meta جاهزة بتكلفة صفرية — تُعرض كشارة
	$students_count = $show_students ? (int) get_post_meta( $course_id, TCF_META_STUDENTS, true ) : 0;

	// هل الدورة جديدة؟ (آخر 7 أيام)
	$is_new    = false;
	$published = get_post_time( 'U', true, $course_id );
	if ( $published && ( time() - $published ) <= ( 7 * DAY_IN_SECONDS ) ) {
		$is_new = true;
	}
	?>
	<div class="tcf-course">
		<div class="tcf-thumb">
			<?php if ( has_post_thumbnail( $course_id ) ) {
				echo get_the_post_thumbnail( $course_id, 'medium_large', array( 'loading' => 'lazy' ) );
			} ?>
			<?php if ( $is_new ) : ?>
				<span class="tcf-ribbon tcf-ribbon-new"><?php echo esc_html__( 'جديد', 'tutor-courses-filter-pro' ); ?></span>
			<?php endif; ?>
		</div>
		<div class="tcf-course-content">
			<h3 class="tcf-title">
				<a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>"<?php echo $open_in_new_tab ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>><?php echo esc_html( get_the_title( $course_id ) ); ?></a>
			</h3>
			<div class="tcf-meta-top">
				<?php if ( $level ) : ?><span class="tcf-badge"><?php echo esc_html( $level ); ?></span><?php endif; ?>
				<?php if ( $rating && ! empty( $rating->rating_avg ) ) : ?>
					<span class="tcf-rating">★ <?php echo esc_html( number_format_i18n( $rating->rating_avg, 1 ) ); ?>
						<span class="tcf-rating-count">(<?php echo esc_html( $rating->rating_count ); ?>)</span>
					</span>
				<?php endif; ?>
			</div>
			<div class="tcf-meta-bottom">
				<?php if ( $lessons ) : ?><span class="tcf-meta-item">📚 <?php echo esc_html( sprintf( /* translators: %d: عدد الدروس */ __( '%d درس', 'tutor-courses-filter-pro' ), $lessons ) ); ?></span><?php endif; ?>
				<?php if ( $duration ) : ?><span class="tcf-meta-item">⏱ <?php echo esc_html( $duration ); ?></span><?php endif; ?>
				<?php if ( $students_count > 0 ) : ?>
					<span class="tcf-meta-item tcf-students">👥 <?php echo esc_html( sprintf( /* translators: %s: عدد الطلاب */ __( '%s طالب', 'tutor-courses-filter-pro' ), number_format_i18n( $students_count ) ) ); ?></span>
				<?php endif; ?>
				<?php if ( $price_html ) : ?>
					<span class="tcf-meta-item tcf-price <?php echo $is_free ? 'tcf-price-free' : 'tcf-price-paid'; ?>"><?php echo esc_html( $price_html ); ?></span>
				<?php endif; ?>
			</div>
			<?php if ( $show_enroll ) : ?>
			<div class="tcf-course-action">
				<a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>" class="tcf-enroll-btn"<?php echo $open_in_new_tab ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>>
					<?php echo esc_html( $enroll_btn_text ); ?>
				</a>
			</div>
			<?php endif; ?>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

function tcf_render_courses_from_posts( $posts, $show_level, $show_rating, $show_lessons, $show_duration, $show_price, $show_students = true, $show_enroll = true, $term = null, $enroll_btn_text = '', $open_in_new_tab = false ) {

	if ( '' === $enroll_btn_text ) {
		$enroll_btn_text = __( 'تسجيل في الدورة', 'tutor-courses-filter-pro' );
	}

	if ( empty( $posts ) ) {
		return '<div class="tcf-row"><div class="tcf-course" style="justify-content:center;align-items:center;min-height:240px;"><p style="color:#999;margin:0;">' . esc_html__( 'لا توجد دورات في هذا التصنيف', 'tutor-courses-filter-pro' ) . '</p></div></div>';
	}

	ob_start();
	?>
	<div class="tcf-row">
		<?php foreach ( $posts as $post ) :
			echo tcf_render_course_card( $post, $show_level, $show_rating, $show_lessons, $show_duration, $show_price, $show_students, $show_enroll, $enroll_btn_text, $open_in_new_tab ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		endforeach; wp_reset_postdata(); ?>
	</div>

	<?php
	return ob_get_clean();
}

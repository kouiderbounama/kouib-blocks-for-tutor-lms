<?php
/**
 * رندر بلوك مربعات تصنيفات الدورات (tcf/courses-categories).
 *
 * يُرسم شبكة أعمدة متجاوبة من تصنيفات course-category، كل مربع يعرض:
 * أيقونة مخصصة (صورة مرفوعة من مكتبة الوسائط في attributes['icons']
 * بمفتاح termId => url) فوق الاسم، وعدد الدورات، وربط بأرشيف التصنيف.
 * يستعير أدوات التطبيق tcfc_clamp() و tcfc_sanitize_primary_color()
 * المعرّفة في carousel-render.php. الكاش منفصل ببادئة tcfcat_ ويُسجَّل
 * كمفتاح نشط فيتفجّر تلقائياً مع دواعم الإبطال المشتركة.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * الرندر الأساسي لشبكة تصنيفات الدورات.
 */
function tcf_render_courses_categories( $attributes ) {

	$is_editor_request = defined( 'REST_REQUEST' ) && REST_REQUEST;

	// الكاش: فحص مبكر قبل أي استعلام أو رسم
	$cache_key = null;
	if ( ! $is_editor_request ) {
		$cache_attributes = $attributes;
		ksort( $cache_attributes );
		$cache_key = 'tcfcat_' . TCF_VERSION . '_' . md5( wp_json_encode( $cache_attributes ) );
		tcf_register_active_key( $cache_key );

		$cached = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}
	}

	tcf_enqueue_frontend_assets( 'categories' );

	$columns        = isset( $attributes['columns'] ) ? tcfc_clamp( $attributes['columns'], 1, 6 ) : 3;
	$columns_tablet = isset( $attributes['columnsTablet'] ) ? tcfc_clamp( $attributes['columnsTablet'], 1, 6 ) : 2;
	$columns_mobile = isset( $attributes['columnsMobile'] ) ? tcfc_clamp( $attributes['columnsMobile'], 1, 6 ) : 1;
	$show_count     = ! empty( $attributes['showCount'] );
	$hide_empty     = ! empty( $attributes['hideEmpty'] );
	$open_in_new    = ! empty( $attributes['openInNewTab'] );
	$primary_color  = tcfc_sanitize_primary_color( isset( $attributes['primaryColor'] ) ? $attributes['primaryColor'] : '#2a7be4' );

	$terms = tcf_get_terms_list( $hide_empty );
	if ( empty( $terms ) ) {
		return '<p style="text-align:center;padding:40px;color:#666;">' . esc_html__( 'لا توجد تصنيفات دورات متاحة حالياً.', 'tutor-courses-filter-pro' ) . '</p>';
	}

	// خريطة الأيقونات المرفوعة: termId => url
	$icon_map = array();
	if ( ! empty( $attributes['icons'] ) && is_array( $attributes['icons'] ) ) {
		foreach ( $attributes['icons'] as $ic ) {
			if ( ! is_array( $ic ) ) {
				continue;
			}
			$term_id = isset( $ic['termId'] ) ? (int) $ic['termId'] : 0;
			$url     = isset( $ic['url'] ) ? $ic['url'] : '';
			if ( $term_id && '' !== $url ) {
				$icon_map[ $term_id ] = sanitize_url( $url );
			}
		}
	}

	$our_style  = '--tcf-primary:' . esc_attr( $primary_color ) . ';';
	$our_style .= '--tcf-cat-cols:' . absint( $columns ) . ';';
	$our_style .= '--tcf-cat-cols-tablet:' . absint( $columns_tablet ) . ';';
	$our_style .= '--tcf-cat-cols-mobile:' . absint( $columns_mobile ) . ';';

	$direction = is_rtl() ? 'rtl' : 'ltr';
	$our_style .= 'direction:' . $direction . ';';

	if ( function_exists( 'get_block_wrapper_attributes' ) ) {
		$wrapper_attrs = get_block_wrapper_attributes( array(
			'class' => 'tcf-categories-wrapper',
			'style' => $our_style,
		) );
	} else {
		$wrapper_attrs = sprintf(
			'class="tcf-categories-wrapper" style="%s"',
			esc_attr( $our_style )
		);
	}

	ob_start();
	?>
	<div <?php echo $wrapper_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- مُهربّة داخلياً ?>>
		<div class="tcf-categories-grid">
			<?php foreach ( $terms as $term ) : ?>
				<?php
				$term_link = get_term_link( $term, 'course-category' );
				if ( is_wp_error( $term_link ) ) {
					$term_link = '';
				}
				$icon_url = isset( $icon_map[ $term->term_id ] ) ? $icon_map[ $term->term_id ] : '';
				$count    = (int) $term->count;
				?>
				<a
					class="tcf-cat-box"
					href="<?php echo esc_url( $term_link ); ?>"
					<?php echo $open_in_new ? 'target="_blank" rel="noopener"' : ''; ?>
				>
					<span class="tcf-cat-icon">
						<?php if ( '' !== $icon_url ) : ?>
							<img
								src="<?php echo esc_url( $icon_url ); ?>"
								alt="<?php echo esc_attr( $term->name ); ?>"
								loading="lazy"
								decoding="async"
							/>
						<?php else : ?>
							<svg viewBox="0 0 24 24" width="40" height="40" aria-hidden="true" focusable="false">
								<path fill="currentColor" d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/>
							</svg>
						<?php endif; ?>
					</span>
					<span class="tcf-cat-name"><?php echo esc_html( $term->name ); ?></span>
					<?php if ( $show_count ) : ?>
						<span class="tcf-cat-count">
							<?php
							/* translators: %s: عدد الدورات في التصنيف */
							echo esc_html( sprintf( _n( '%s دورة', '%s دورات', $count, 'tutor-courses-filter-pro' ), number_format_i18n( $count ) ) );
							?>
						</span>
					<?php endif; ?>
				</a>
			<?php endforeach; ?>
		</div>
	</div>
	<?php
	$html = ob_get_clean();

	if ( null !== $cache_key ) {
		set_transient( $cache_key, $html, tcf_get_cache_ttl() );
	}

	return $html;
}
<?php
/**
 * رندر بلوك كاروسيل الدورات (tcf/courses-carousel).
 *
 * يعتمد على نفس طبقة الاستعلام المجمّع من render.php
 * (tcf_build_query_args + tcf_get_grouped_courses) وعلى رسم البطاقات
 * المشتركة tcf_render_course_card(). الكاش منفصل ببادئة tcfc_html_ ويُسجَّل
 * كمفتاح نشط فيتفجّر تلقائياً مع بقية كاش الإضافة.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * يرخّص قيماً رقمية ضمن مدى معين.
 */
function tcfc_clamp( $value, $min, $max ) {
	return max( $min, min( $max, (int) $value ) );
}

/**
 * يرجع لون أساسي آمن (hex أو rgb/rgba) أو الافتراضي عند عدم الصلاحية.
 */
function tcfc_sanitize_primary_color( $color ) {
	if ( preg_match( '/^#[0-9a-fA-F]{3,8}$/', $color )
		|| preg_match( '/^rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*(,\s*[\d.]+\s*)?\)$/', $color ) ) {
		return $color;
	}
	return '#2a7be4';
}

/**
 * الرندر الأساسي للكاروسيل.
 */
function tcf_render_courses_carousel( $attributes ) {

	$is_editor_request = defined( 'REST_REQUEST' ) && REST_REQUEST;

	$orderby_attr = isset( $attributes['orderby'] ) ? $attributes['orderby'] : 'date';
	$category_ids = isset( $attributes['categories'] )
		? array_map( 'absint', (array) $attributes['categories'] )
		: array();

	// الكاش: الفحص مبكراً قبل أي استعلام أو رسم (عند الإصابة نُعيده مباشرة)
	$cache_key = null;
	if ( ! $is_editor_request && 'rand' !== $orderby_attr ) {
		$cache_attributes = $attributes;
		ksort( $cache_attributes );
		$cache_key = 'tcfc_html_' . TCF_VERSION . '_' . md5( wp_json_encode( $cache_attributes ) );
		tcf_register_active_key( $cache_key );

		$cached = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}
	}

	tcf_enqueue_frontend_assets( 'carousel' );

	$courses_to_show  = isset( $attributes['coursesToShow'] ) ? tcfc_clamp( $attributes['coursesToShow'], 1, 24 ) : 3;
	$columns          = isset( $attributes['columns'] ) ? tcfc_clamp( $attributes['columns'], 1, 4 ) : 3;
	$columns_tablet   = isset( $attributes['columnsTablet'] ) ? tcfc_clamp( $attributes['columnsTablet'], 1, 4 ) : 2;
	$columns_mobile   = isset( $attributes['columnsMobile'] ) ? tcfc_clamp( $attributes['columnsMobile'], 1, 4 ) : 1;
	$autoplay         = ! empty( $attributes['autoplay'] );
	$autoplay_speed   = isset( $attributes['autoplaySpeed'] ) ? tcfc_clamp( $attributes['autoplaySpeed'], 1000, 10000 ) : 3000;
	$speed            = isset( $attributes['speed'] ) ? tcfc_clamp( $attributes['speed'], 100, 2000 ) : 500;
	$infinite_loop    = ! empty( $attributes['infiniteLoop'] );
	$show_arrows      = ! empty( $attributes['showArrows'] );
	$show_dots        = ! empty( $attributes['showDots'] );
	$pause_on_hover   = ! empty( $attributes['pauseOnHover'] );
	$show_level       = ! empty( $attributes['showLevel'] );
	$show_rating      = ! empty( $attributes['showRating'] );
	$show_lessons     = ! empty( $attributes['showLessons'] );
	$show_duration    = ! empty( $attributes['showDuration'] );
	$show_price       = ! empty( $attributes['showPrice'] );
	$show_students    = ! empty( $attributes['showStudents'] );
	$show_enroll      = ! empty( $attributes['showEnrollBtn'] );
	$open_in_new_tab  = ! empty( $attributes['openInNewTab'] );
	$primary_color    = tcfc_sanitize_primary_color( isset( $attributes['primaryColor'] ) ? $attributes['primaryColor'] : '#2a7be4' );

	$enroll_btn_text = isset( $attributes['enrollBtnText'] ) ? sanitize_text_field( $attributes['enrollBtnText'] ) : '';
	if ( '' === $enroll_btn_text ) {
		$enroll_btn_text = __( 'تسجيل في الدورة', 'tutor-courses-filter-pro' );
	}

	$query_args = tcf_build_query_args( $orderby_attr, $category_ids );
	// استعلام مُقيَّد بعدد الدورات المطلوبة فقط (لا تحميل كل الدورات كاملات):
	// أفضل أداء في الصفحات والكاش، ويحترم الترتيب والتصنيفات.
	$posts = tcf_get_courses_bounded( $query_args, $courses_to_show );

	if ( empty( $posts ) ) {
		return '<p style="text-align:center;padding:40px;color:#666;">' . esc_html__( 'لا توجد دورات متاحة حالياً.', 'tutor-courses-filter-pro' ) . '</p>';
	}

	$our_style  = '--tcf-primary:' . esc_attr( $primary_color ) . ';';
	$our_style .= '--tcf-carousel-columns-desktop:' . absint( $columns ) . ';';
	$our_style .= '--tcf-carousel-columns-tablet:' . absint( $columns_tablet ) . ';';
	$our_style .= '--tcf-carousel-columns-mobile:' . absint( $columns_mobile ) . ';';
	$our_style .= '--tcf-carousel-gap:22px;';

	$direction = is_rtl() ? 'rtl' : 'ltr';
	$our_style .= 'direction:' . $direction . ';';

	if ( function_exists( 'get_block_wrapper_attributes' ) ) {
		$wrapper_attrs = get_block_wrapper_attributes( array(
			'class' => 'tcf-carousel-wrapper',
			'style' => $our_style,
		) );
	} else {
		$wrapper_attrs = sprintf(
			'class="tcf-carousel-wrapper" style="%s"',
			esc_attr( $our_style )
		);
	}

	// بيانات JS: إعدادات الحركة والتنقل
	$wrapper_attrs .= sprintf(
		' dir="%1$s" data-tcfc-autoplay="%2$s" data-tcfc-autoplay-speed="%3$d" data-tcfc-speed="%4$d" data-tcfc-infinite="%5$s" data-tcfc-arrows="%6$s" data-tcfc-dots="%7$s" data-tcfc-hover-pause="%8$s" data-tcfc-columns="%9$d" data-tcfc-cols-tablet="%10$d" data-tcfc-cols-mobile="%11$d"',
		esc_attr( $direction ),
		$autoplay ? '1' : '0',
		absint( $autoplay_speed ),
		absint( $speed ),
		$infinite_loop ? '1' : '0',
		$show_arrows ? '1' : '0',
		$show_dots ? '1' : '0',
		$pause_on_hover ? '1' : '0',
		absint( $columns ),
		absint( $columns_tablet ),
		absint( $columns_mobile )
	);

	ob_start();
	?>
	<div <?php echo $wrapper_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- مُهربّة داخلياً ?>>
		<div class="tcf-carousel<?php echo $show_arrows ? '' : ' tcfc-no-arrows'; ?>">
			<div class="tcf-carousel-viewport">
				<div class="tcf-carousel-track">
					<?php foreach ( $posts as $post ) : ?>
						<div class="tcf-carousel-slide">
							<?php echo tcf_render_course_card( $post, $show_level, $show_rating, $show_lessons, $show_duration, $show_price, $show_students, $show_enroll, $enroll_btn_text, $open_in_new_tab ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</div>
					<?php endforeach; wp_reset_postdata(); ?>
				</div>
			</div>
			<?php if ( $show_arrows ) : ?>
				<?php
				// الأسهم في RTL تُعكس: السابق (يمين) يشير لليمين، التالي (يسار) لليسار
				$chevron_left  = 'M15.41 7.41 14 6l-6 6 6 6 1.41-1.41L10.83 12z';
				$chevron_right = 'M8.59 16.59 10 18l6-6-6-6-1.41 1.41L13.17 12z';
				$prev_path     = ( 'rtl' === $direction ) ? $chevron_right : $chevron_left;
				$next_path     = ( 'rtl' === $direction ) ? $chevron_left : $chevron_right;
				?>
				<button type="button" class="tcf-carousel-prev" aria-label="<?php esc_attr_e( 'السابق', 'tutor-courses-filter-pro' ); ?>">
					<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="<?php echo esc_attr( $prev_path ); ?>"/></svg>
				</button>
				<button type="button" class="tcf-carousel-next" aria-label="<?php esc_attr_e( 'التالي', 'tutor-courses-filter-pro' ); ?>">
					<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="<?php echo esc_attr( $next_path ); ?>"/></svg>
				</button>
			<?php endif; ?>
		</div>
		<?php if ( $show_dots ) : ?>
			<div class="tcf-carousel-dots" aria-label="<?php esc_attr_e( 'تنقل الدورات', 'tutor-courses-filter-pro' ); ?>"></div>
		<?php endif; ?>
	</div>
	<?php
	$html = ob_get_clean();

	// الكاش لا يُخزَّن في المحرر، ولا مع الترتيب العشوائي (كي يبقى طازجاً)
	if ( null !== $cache_key ) {
		set_transient( $cache_key, $html, tcf_get_cache_ttl() );
	}

	return $html;
}
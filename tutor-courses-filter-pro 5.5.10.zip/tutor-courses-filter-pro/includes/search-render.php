<?php
/**
 * رندر بلوك البحث السريع في الدورات (tcf/courses-search).
 *
 * يخرج حقل بحث + حاوية نتائج، ويحوّل خيارات العرض إلى data-attributes
 * يقرؤها سكربت الواجهة (assets/js/search.js) فيرسل طلبات REST.
 * دوال توليد عناصر النتائج (tcf_search_courses_html) مشتركة بين REST
 * والرندر كي يكون المظهر واحداً في كل المسارات.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * مدة كاش نتائج البحث (بالثانية). قصير عمداً؛ ينتهي ذاتياً ولا يُسجَّل في
 * مفاتيح الإبطال المشتركة كي لا يلوّث سجل الكاش بآلاف الاستعلامات المتنوعة.
 * قابل للتعديل: add_filter( 'tcf_search_cache_ttl', fn() => 3 * MINUTE_IN_SECONDS );
 */
function tcf_get_search_cache_ttl() {
	return (int) apply_filters( 'tcf_search_cache_ttl', 2 * MINUTE_IN_SECONDS );
}

/**
 * يقتطع نص البحث ويطبّعه للاستعلام بحد أقصى معقول.
 */
function tcf_sanitize_search_query( $q ) {
	$q = sanitize_text_field( is_string( $q ) ? $q : '' );
	return function_exists( 'mb_substr' ) ? mb_substr( $q, 0, 100 ) : substr( $q, 0, 100 );
}

/**
 * يطبّع لوناً مخصصاً للفورم (hex/rgb/rgba) أو يُعيد '' عند عدم الصلاحية/الفارغ.
 */
function tcf_sanitize_search_color( $color ) {
	$color = is_string( $color ) ? trim( $color ) : '';
	if ( preg_match( '/^#[0-9a-fA-F]{3,8}$/', $color )
		|| preg_match( '/^rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*(,\s*[\d.]+\s*)?\)$/', $color ) ) {
		return $color;
	}
	return '';
}

/**
 * يطبّع نصاً عربياً للبحث: يزيل التشكيل/التنوين/التطويل، يوحّد الحروف
 * المتشابهة (أ/إ/آ/ٱ→ا، ة→ه، ى→ي، ؤ→و، ئ→ي)، يخفّض اللاتينية، ويكبس
 * الفراغات. يُستخدم على طرفي المقارنة (نص البحث + تعبير SQL للعمود).
 */
function tcf_normalize_arabic( $text ) {
	if ( ! is_string( $text ) || '' === $text ) {
		return '';
	}

	// إزالة التشكيل والتنوين والتطويل
	$text = preg_replace( '/[\x{064B}-\x{065F}\x{0670}\x{0640}]/u', '', $text );

	// توحيد الحروف
	$map = array(
		'أ' => 'ا',
		'إ' => 'ا',
		'آ' => 'ا',
		'ٱ' => 'ا',
		'ة' => 'ه',
		'ى' => 'ي',
		'ؤ' => 'و',
		'ئ' => 'ي',
	);
	$text = strtr( $text, $map );

	// تصغير + كبس الفراغات
	$text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text ) : strtolower( $text );

	return trim( preg_replace( '/\s+/u', ' ', $text ) );
}

/**
 * يعيد تعبير SQL يطبّع عموداً نصياً بنفس قواعد tcf_normalize_arabic
 * (سلسلة REPLACE متداخلة خفيفة)، كي تُقارن بالنمط المطبّع بـ LIKE عادية.
 * ملاحظة: إزالة التشكيل تتم في طرف الاستعلام فقط؛ وجود تشكيل كثيف في
 * عناوين المخزون حالة نادرة جداً لا تستحق ثقل REPLACE إضافياً لكل صف.
 *
 * @param string $column مرجع عمود كامل مثل "wp_posts.post_title".
 * @return string تعبير SQL جاهز للوضع في WHERE/ORDER BY.
 */
function tcf_sql_normalize_column( $column ) {
	$replaces = array(
		array( 'أ', 'ا' ),
		array( 'إ', 'ا' ),
		array( 'آ', 'ا' ),
		array( 'ٱ', 'ا' ),
		array( 'ة', 'ه' ),
		array( 'ى', 'ي' ),
		array( 'ؤ', 'و' ),
		array( 'ئ', 'ي' ),
	);

	$expr = $column;
	foreach ( $replaces as $pair ) {
		$expr = 'REPLACE(' . $expr . ",'" . $pair[0] . "','" . $pair[1] . "')";
	}

	return 'LOWER(' . $expr . ')';
}

/**
 * يجمع معرفات الدورات المطابقة عبر LIKE على أعمدة مطبّعة، بوضع عبارة
 * كاملة أو تفكيك كلمات (كلمتان حرفان فأكثر، وأي كلمة تكفي).
 * الترتيب بالصلة داخل مرحلة العناوين: تطابق تام > يبدأ بالعبارة > يحويها.
 *
 * @param string $q        نص البحث (يُطبَّع داخل الدالة).
 * @param int    $per_page أقصى عدد معرفات.
 * @param array  $exclude  معرفات مستبعدة (من مراحل أسبق).
 * @param array  $fields   الحقول: post_title / post_excerpt / post_content.
 * @param bool   $phrase   true = العبارة كاملة كنص واحد؛ false = أي كلمة.
 * @return array معرفات صحيحة.
 */
function tcf_search_ids_query( $q, $per_page, $exclude = array(), $fields = array( 'post_title' ), $phrase = false ) {
	global $wpdb;

	$q = tcf_normalize_arabic( $q );
	if ( '' === $q ) {
		return array();
	}

	$terms = array();
	if ( $phrase ) {
		$terms[] = $q;
	} else {
		foreach ( preg_split( '/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY ) as $t ) {
			// تجاهل الحروف/الكلمات أحادية الرسم حتى لا تلوّث النتائج
			if ( ( function_exists( 'mb_strlen' ) ? mb_strlen( $t ) : strlen( $t ) ) >= 2 ) {
				$terms[] = $t;
			}
		}
	}
	if ( empty( $terms ) ) {
		return array();
	}

	$all_fields = array_values( array_intersect( array( 'post_title', 'post_excerpt', 'post_content' ), (array) $fields ) );
	if ( empty( $all_fields ) ) {
		return array();
	}

	$clauses = array();
	$params  = array();
	foreach ( $all_fields as $f ) {
		$col = tcf_sql_normalize_column( "{$wpdb->posts}.{$f}" );
		foreach ( $terms as $t ) {
			$clauses[] = "{$col} LIKE %s";
			$params[]  = '%' . $wpdb->esc_like( $t ) . '%';
		}
	}

	$sql    = "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'courses' AND post_status = 'publish' AND (" . implode( ' OR ', $clauses ) . ')';

	if ( ! empty( $exclude ) ) {
		$exclude = array_values( array_unique( array_map( 'intval', $exclude ) ) );
		$sql    .= ' AND ID NOT IN (' . implode( ',', $exclude ) . ')';
	}

	if ( in_array( 'post_title', $all_fields, true ) ) {
		// الصلة: عنوان مطابق تماماً > يبدأ بالعبارة > يحويها > ثم الأحدث
		$ttl      = tcf_sql_normalize_column( "{$wpdb->posts}.post_title" );
		$sql     .= ' ORDER BY CASE'
			. ' WHEN ' . $ttl . ' = %s THEN 0'
			. ' WHEN ' . $ttl . ' LIKE %s THEN 1'
			. ' WHEN ' . $ttl . ' LIKE %s THEN 2'
			. ' ELSE 3 END'
			. ", {$wpdb->posts}.post_date DESC";
		$params[]  = $q;
		$params[]  = $wpdb->esc_like( $q ) . '%';
		$params[]  = '%' . $wpdb->esc_like( $q ) . '%';
	} else {
		$sql .= " ORDER BY {$wpdb->posts}.post_date DESC";
	}

	$sql      .= ' LIMIT %d';
	$params[]  = max( 1, min( 12, (int) $per_page ) );

	return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( $sql, $params ) ) );
}

/**
 * الرندر الأساسي لحقل البحث.
 */
function tcf_render_courses_search( $attributes ) {
	$placeholder = isset( $attributes['placeholder'] ) ? sanitize_text_field( $attributes['placeholder'] ) : '';
	// حارس ضد placeholder تالف (مزدوج الترميز Ø§Ø¨Ø­Ø«...) محفوظ في خصائص
	// البلوك من نسخة معيبة قديمة: إن احتوى بايتات C2/C3 اللاتينية دون أحرف
	// عربية تُعامل كفارغ ونعتمد النص النظيف.
	if ( '' !== $placeholder
		&& 1 === preg_match( '/[\xC2\xC3]/', $placeholder )
		&& ! preg_match( '/[\x{0620}-\x{06FF}]/u', $placeholder ) ) {
		$placeholder = '';
	}
	if ( '' === $placeholder ) {
		$placeholder = __( 'ابحث عن دورة...', 'tutor-courses-filter-pro' );
	}

	$per_page      = isset( $attributes['perPage'] ) ? max( 1, min( 12, (int) $attributes['perPage'] ) ) : 6;
	$field_width   = isset( $attributes['fieldWidth'] ) ? max( 160, min( 1200, (int) $attributes['fieldWidth'] ) ) : 460;
	$form_align    = isset( $attributes['formAlign'] ) ? $attributes['formAlign'] : 'left';
	if ( ! in_array( $form_align, array( 'left', 'center', 'right' ), true ) ) {
		$form_align = 'left';
	}
	$overlay_results = ! empty( $attributes['overlayResults'] );
	$show_thumb    = ! empty( $attributes['showThumb'] );
	$full_phrase   = ! empty( $attributes['fullPhrase'] );
	$show_price    = ! empty( $attributes['showPrice'] );
	$show_rating   = ! empty( $attributes['showRating'] );
	$show_students = ! empty( $attributes['showStudents'] );
	$open_in_new   = ! empty( $attributes['openInNewTab'] );
	$primary_color = tcfc_sanitize_primary_color( isset( $attributes['primaryColor'] ) ? $attributes['primaryColor'] : '#2a7be4' );
	$field_bg      = tcf_sanitize_search_color( isset( $attributes['fieldBg'] ) ? $attributes['fieldBg'] : '' );
	$field_border  = tcf_sanitize_search_color( isset( $attributes['fieldBorder'] ) ? $attributes['fieldBorder'] : '' );
	$field_text    = tcf_sanitize_search_color( isset( $attributes['fieldText'] ) ? $attributes['fieldText'] : '' );
	$icon_color    = tcf_sanitize_search_color( isset( $attributes['iconColor'] ) ? $attributes['iconColor'] : '' );

	tcf_enqueue_frontend_assets( 'search' );

	$our_style  = '--tcf-primary:' . esc_attr( $primary_color ) . ';';
	if ( '' !== $field_bg ) {
		$our_style .= '--tcf-search-bg:' . esc_attr( $field_bg ) . ';';
	}
	if ( '' !== $field_border ) {
		$our_style .= '--tcf-search-border:' . esc_attr( $field_border ) . ';';
	}
	if ( '' !== $field_text ) {
		$our_style .= '--tcf-search-text:' . esc_attr( $field_text ) . ';';
	}
	if ( '' !== $icon_color ) {
		$our_style .= '--tcf-search-icon:' . esc_attr( $icon_color ) . ';';
	}

	// عرض الحقل قابل للتحكم (لا يأخذ عرض الصفحة الكامل) + المحاذاة
	$our_style .= 'width:' . absint( $field_width ) . 'px;max-width:100%;';
	if ( 'center' === $form_align ) {
		$our_style .= 'margin:0 auto;';
	} elseif ( 'right' === $form_align ) {
		$our_style .= 'margin-left:auto;margin-right:0;';
	} else {
		$our_style .= 'margin-left:0;margin-right:auto;';
	}
	$direction  = is_rtl() ? 'rtl' : 'ltr';
	$our_style .= 'direction:' . $direction . ';';

	if ( function_exists( 'get_block_wrapper_attributes' ) ) {
		$wrapper_attrs = get_block_wrapper_attributes( array(
			'class' => 'tcf-search-wrapper',
			'style' => $our_style,
		) );
	} else {
		$wrapper_attrs = sprintf(
			'class="tcf-search-wrapper" style="%s"',
			esc_attr( $our_style )
		);
	}

	// بيانات JS: نهاية REST + خيارات العرض + رسالة خطأ مترجمة
	$wrapper_attrs .= sprintf(
		' dir="%1$s" data-tcf-search="1" data-tcfs-rest="%2$s" data-tcfs-perpage="%3$d" data-tcfs-showthumb="%4$s" data-tcfs-showprice="%5$s" data-tcfs-showrating="%6$s" data-tcfs-showstudents="%7$s" data-tcfs-open="%8$s" data-tcfs-phrase="%9$s" data-tcfs-error="%10$s"',
		esc_attr( $direction ),
		esc_url( rest_url( 'tcf/v1/search' ) ),
		absint( $per_page ),
		$show_thumb ? '1' : '0',
		$show_price ? '1' : '0',
		$show_rating ? '1' : '0',
		$show_students ? '1' : '0',
		$open_in_new ? '1' : '0',
		$full_phrase ? '1' : '0',
		esc_attr( __( 'تعذّر البحث الآن، حاول لاحقاً.', 'tutor-courses-filter-pro' ) )
	);

	ob_start();
	?>
	<div <?php echo $wrapper_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- مُهربّة داخلياً ?>>
		<div class="tcf-search-field">
			<svg class="tcf-search-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false">
				<path fill="currentColor" d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
			</svg>
			<input
				type="search"
				class="tcf-search-input"
				value=""
				placeholder="<?php echo esc_attr( $placeholder ); ?>"
				autocomplete="off"
				enterkeyhint="search"
				role="combobox"
				aria-autocomplete="list"
				aria-expanded="false"
				aria-controls="tcf-search-results"
				aria-label="<?php echo esc_attr( $placeholder ); ?>"
			/>
			<span class="tcf-search-spinner" hidden></span>
		</div>
		<div class="tcf-search-results<?php echo $overlay_results ? '' : ' tcf-search-inline'; ?>" id="tcf-search-results" role="listbox" hidden></div>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * يبني HTML عنصر نتيجة واحد (متوافق مع أسلوب بطاقات الإضافة الخفيفة).
 *
 * @param WP_Post $post         الدورة.
 * @param array   $args         خيارات العرض (show_thumb, show_price, show_rating, show_students, open_new).
 * @return string HTML آمناً.
 */
function tcf_search_result_item( $post, $args ) {
	$course_id  = $post->ID;
	$permalink  = get_permalink( $course_id );
	$open_new   = ! empty( $args['open_new'] );
	$show_thumb = ! empty( $args['show_thumb'] );
	$show_price = ! empty( $args['show_price'] );
	$show_rate  = ! empty( $args['show_rating'] );
	$show_stud  = ! empty( $args['show_students'] );

	$thumb_html = '';
	if ( $show_thumb && has_post_thumbnail( $course_id ) ) {
		$thumb_html = '<span class="tcf-search-thumb">' . get_the_post_thumbnail( $course_id, 'thumbnail', array( 'loading' => 'lazy', 'decoding' => 'async' ) ) . '</span>';
	}

	$meta = array();

	if ( $show_rate ) {
		$rating = tcf_card_rating( $course_id );
		if ( $rating && ! empty( $rating->rating_avg ) ) {
			$meta[] = '<span class="tcf-search-meta tcf-search-rating">★ ' . esc_html( number_format_i18n( $rating->rating_avg, 1 ) ) . '</span>';
		}
	}

	if ( $show_stud ) {
		$students = (int) get_post_meta( $course_id, TCF_META_STUDENTS, true );
		if ( $students > 0 ) {
			$meta[] = '<span class="tcf-search-meta tcf-search-students">' . esc_html( sprintf(
				/* translators: %s: عدد الطلاب */
				__( '%s طالب', 'tutor-courses-filter-pro' ),
				number_format_i18n( $students )
			) ) . '</span>';
		}
	}

	if ( $show_price ) {
		$price = tcf_get_course_price_text( $course_id );
		if ( '' !== $price ) {
			$is_free = ( 'free' === get_post_meta( $course_id, '_tutor_course_price_type', true ) );
			$meta[]  = '<span class="tcf-search-meta tcf-search-price ' . ( $is_free ? 'tcf-search-price-free' : 'tcf-search-price-paid' ) . '">' . esc_html( $price ) . '</span>';
		}
	}

	$extra = $open_new ? ' target="_blank" rel="noopener noreferrer"' : '';

	return sprintf(
		'<a class="tcf-search-item" href="%s" role="option"%s>%s<span class="tcf-search-body"><span class="tcf-search-title">%s</span>%s</span></a>',
		esc_url( $permalink ),
		$extra,
		$thumb_html,
		esc_html( get_the_title( $course_id ) ),
		$meta ? '<span class="tcf-search-meta-wrap">' . implode( '', $meta ) . '</span>' : ''
	);
}

/**
 * ينفّذ البحث ويُعيد HTML القائمة الجاهزة (أو رسالة "لا توجد نتائج").
 * مشترك بين REST endpoint وواجهة الرندر.
 *
 * المراحل: عناوين مطبّعة عربياً بترتيب الصلة (تام > بادئة > حشوّ) ثم
 * تعبئة من العنوان/المقتطف/المحتوى ثم استكمال من التصنيفات المطابقة
 * لأسمائها — كلها على نص مطبّع (أ/إ/آ→ا، ة→ه، ى→ي، بلا تشكيل).
 *
 * @param string $q         نص البحث.
 * @param int    $per_page  عدد النتائج (1-12).
 * @param array  $flags     خيارات العرض (+ sentence للعبارة الكاملة).
 * @return string HTML آمناً.
 */
function tcf_search_courses_html( $q, $per_page = 6, $flags = array() ) {
	global $wpdb;

	$q        = tcf_normalize_arabic( tcf_sanitize_search_query( $q ) );
	$per_page = max( 1, min( 12, (int) $per_page ) );

	if ( '' === $q ) {
		return '<p class="tcf-search-no-results">' . esc_html__( 'اكتب للبحث عن دورات...', 'tutor-courses-filter-pro' ) . '</p>';
	}

	// كاش قصير ذاتي الانتهاء للاستعلامات الشائعة (والأهم: الأجزاء أثناء الكتابة).
	// المفتاح على النص المطبّع — فيشارك "أحمد" و"احمد" نفس النتيجة والكاش.
	// لا يُسجَّل في مفاتيح الإبطال المشتركة — ينتهي بـ TTL دون أي أثر.
	$cacheable = ( function_exists( 'mb_strlen' ) ? mb_strlen( $q ) : strlen( $q ) ) >= 3;
	$cache_key = null;
	if ( $cacheable ) {
		$bits      = array( 'q' => $q, 'pp' => $per_page, 'f' => $flags );
		ksort( $bits );
		$cache_key = 'tcf_srch_' . TCF_VERSION . '_' . md5( wp_json_encode( $bits ) );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}
	}

	// 1) المرحلة الأولى — مطابقة العناوين فقط: الأدق وأقرب لنية المستخدم
	$sentence = ! empty( $flags['sentence'] );
	$ids      = tcf_search_ids_query( $q, $per_page, array(), array( 'post_title' ), $sentence );

	// 2) المرحلة الثانية — تعبئة الباقي من العناوين + المقتطف + المحتوى
	if ( count( $ids ) < $per_page ) {
		$more = tcf_search_ids_query(
			$q,
			$per_page - count( $ids ),
			$ids,
			array( 'post_title', 'post_excerpt', 'post_content' ),
			$sentence
		);
		$ids = array_merge( $ids, $more );
	}

	// 3) المرحلة الثالثة — دورات التصنيفات المطابقة لأسمائها (مطبّعة عربياً) لاستكمال النتيجة
	if ( count( $ids ) < $per_page ) {
		$col      = tcf_sql_normalize_column( "{$wpdb->terms}.name" );
		$term_ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare(
			"SELECT tt.term_id FROM {$wpdb->term_taxonomy} tt"
			. " INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id"
			. " WHERE tt.taxonomy = 'course-category' AND tt.count > 0 AND {$col} LIKE %s"
			. ' ORDER BY t.name ASC LIMIT 5',
			'%' . $wpdb->esc_like( $q ) . '%'
		) ) );

		if ( ! empty( $term_ids ) ) {
			$by_cat = get_posts( array(
				'post_type'      => 'courses',
				'post_status'    => 'publish',
				'tax_query'      => array(
					array(
						'taxonomy' => 'course-category',
						'field'    => 'term_id',
						'terms'    => $term_ids,
					),
				),
				'exclude'        => $ids,
				'posts_per_page' => $per_page - count( $ids ),
				'no_found_rows'  => true,
			) );

			foreach ( $by_cat as $p ) {
				$ids[] = (int) $p->ID;
			}
		}
	}

	$ids = array_values( array_unique( array_slice( $ids, 0, $per_page ) ) );

	if ( empty( $ids ) ) {
		$html = '<p class="tcf-search-no-results">' . esc_html__( 'لا توجد نتائج مطابقة', 'tutor-courses-filter-pro' ) . '</p>';
	} else {
		$posts = tcf_get_posts_by_ids( $ids );

		$item_html = '';
		foreach ( $posts as $post ) {
			$item_html .= tcf_search_result_item( $post, $flags );
		}
		$html = $item_html;
	}

	if ( null !== $cache_key ) {
		set_transient( $cache_key, $html, tcf_get_search_cache_ttl() );
	}

	return $html;
}
<?php
/**
 * تسجيل أصول البلوك (تُسجَّل على init).
 *
 * - CSS (tcf-style): يُسجَّل كـ handle ويُشار إليه في block.json عبر خاصية `style`,
 *   فيُحمَّل تلقائيًا على الواجهة فقط عند وجود البلوك، وفي المحرر أيضًا.
 * - سكربت الواجهة (tcf-view): يُسجَّل كـ handle ويُشار إليه في block.json عبر
 *   خاصية `viewScript`، فيُحمَّل تلقائيًا على الواجهة عند وجود البلوك فقط.
 *   وفي المحرر نُحمّله عبر enqueue_block_editor_assets حتى تعمل أزرار الفلترة
 *   في معاينة ServerSideRender.
 *
 * ملاحظة توقيت ضرورية: WordPress يبدأ بتحميل أصول البلوك (style/viewScript)
 * من block.json داخل WP_Block::render() قبل تنفيذ render_callback، لذا كان
 * التسجيل المتأخر (داخل الكولباك) يجعل الـ handles غير موجودة ولا تُحمَّل.
 * الحل: تسجيل الأصول مبكراً على hook init.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcf_register_assets() {
	if ( ! wp_style_is( 'tcf-style', 'registered' ) ) {
		wp_register_style( 'tcf-style', TCF_URL . 'assets/css/tcf.css', array(), TCF_VERSION );
	}

	if ( ! wp_script_is( 'tcf-view', 'registered' ) ) {
		wp_register_script( 'tcf-view', TCF_URL . 'assets/js/view.js', array(), TCF_VERSION, true );
	}

	// أصول بلوك الكاروسيل
	if ( ! wp_style_is( 'tcf-carousel-style', 'registered' ) ) {
		wp_register_style( 'tcf-carousel-style', TCF_URL . 'assets/css/tcf-carousel.css', array(), TCF_VERSION );
	}

	if ( ! wp_script_is( 'tcf-carousel-view', 'registered' ) ) {
		wp_register_script( 'tcf-carousel-view', TCF_URL . 'assets/js/carousel.js', array(), TCF_VERSION, true );
	}

	// أصول بلوك مربعات التصنيفات
	if ( ! wp_style_is( 'tcf-categories-style', 'registered' ) ) {
		wp_register_style( 'tcf-categories-style', TCF_URL . 'assets/css/tcf-categories.css', array(), TCF_VERSION );
	}

	// أصول بلوك البحث السريع
	if ( ! wp_style_is( 'tcf-search-style', 'registered' ) ) {
		wp_register_style( 'tcf-search-style', TCF_URL . 'assets/css/tcf-search.css', array(), TCF_VERSION );
	}

	if ( ! wp_script_is( 'tcf-search-view', 'registered' ) ) {
		wp_register_script( 'tcf-search-view', TCF_URL . 'assets/js/search.js', array(), TCF_VERSION, true );
	}
}
add_action( 'init', 'tcf_register_assets' );

/**
 * يضمن تحميل أصول الواجهة (style + viewScript) حتى في المسارات التي لا تُفعَّل
 * فيها التحميل التلقائي من block.json. يُستدعى من render_callback.
 *
 * يُحمَّل كل بلوك أصوله فقط: 'filter' يُحمّل CSS الفلتر + سكربت الفلترة،
 * و 'carousel' يُحمّل CSS الكاروسيل + سكربته بدل تحميل كل شيء في كل صفحة.
 * (CSS الأساسي tcf-style مطلوب في كليهما لأنه يحمل تنسيقات بطاقات الدورات).
 */
function tcf_enqueue_frontend_assets( $which = 'all' ) {
	if ( 'filter' === $which ) {
		wp_enqueue_style( 'tcf-style' );
		wp_enqueue_script( 'tcf-view' );
		return;
	}

	if ( 'carousel' === $which ) {
		wp_enqueue_style( 'tcf-style' );
		wp_enqueue_style( 'tcf-carousel-style' );
		wp_enqueue_script( 'tcf-carousel-view' );
		return;
	}

	if ( 'search' === $which ) {
		wp_enqueue_style( 'tcf-search-style' );
		wp_enqueue_script( 'tcf-search-view' );
		return;
	}

	if ( 'categories' === $which ) {
		wp_enqueue_style( 'tcf-categories-style' );
		return;
	}

	wp_enqueue_style( 'tcf-style' );
	wp_enqueue_style( 'tcf-carousel-style' );
	wp_enqueue_script( 'tcf-view' );
	wp_enqueue_script( 'tcf-carousel-view' );
}

/**
 * تحميل سكربت الفلترة في المحرر (بمعاينة ServerSideRender) حتى تستجيب أزرار
 * التصنيفات داخل iframe المحرر. الكن يستخدم MutationObserver لإعادة التهيئة
 * عند إعادة رندر المعاينة.
 */
function tcf_enqueue_editor_assets() {
	tcf_register_assets();
	wp_enqueue_script( 'tcf-view' );
	wp_enqueue_script( 'tcf-carousel-view' );
	wp_enqueue_style( 'tcf-carousel-style' );
	wp_enqueue_style( 'tcf-categories-style' );
	wp_enqueue_style( 'tcf-search-style' );
}
add_action( 'enqueue_block_editor_assets', 'tcf_enqueue_editor_assets' );

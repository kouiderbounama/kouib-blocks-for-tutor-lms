<?php
/**
 * REST endpoint لتحميل شبكات التصنيفات عند الطلب (بدلاً من تضمينها كلها في HTML).
 *
 * GET /wp-json/tcf/v1/courses?term=all|term-ID&orderby=...&perPage=...
 * يردّ HTML شبكة تصنيف واحد (مخزّن في كاش لكل تصنيف).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', 'tcf_register_rest_route' );
function tcf_register_rest_route() {
	register_rest_route(
		'tcf/v1',
		'/courses',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'tcf_rest_get_courses',
			'permission_callback' => '__return_true',
			'args'                => array(
				'term'        => array(
					'type'              => 'string',
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				),
				'orderby'     => array(
					'type'              => 'string',
					'default'           => 'date',
					'sanitize_callback' => 'sanitize_key',
					'validate_callback' => function( $param ) {
						return in_array( $param, array( 'date', 'date_asc', 'title', 'rand', 'students' ), true );
					},
				),
				'perPage'     => array(
					'type'              => 'integer',
					'default'           => 3,
					'validate_callback' => function( $param ) {
						return is_numeric( $param ) && (int) $param >= 1 && (int) $param <= 24;
					},
				),
				'page'        => array(
					'type'              => 'integer',
					'default'           => 1,
					'validate_callback' => function( $param ) {
						return is_numeric( $param ) && (int) $param >= 1 && (int) $param <= 1000;
					},
				),
				'showLevel'   => array( 'type' => 'boolean', 'default' => true ),
				'showRating'  => array( 'type' => 'boolean', 'default' => true ),
				'showLessons' => array( 'type' => 'boolean', 'default' => true ),
				'showDuration'=> array( 'type' => 'boolean', 'default' => true ),
				'showPrice'   => array( 'type' => 'boolean', 'default' => true ),
				'showStudents'=> array( 'type' => 'boolean', 'default' => true ),
				'showEnrollBtn'=> array( 'type' => 'boolean', 'default' => true ),
				'enrollBtnText'=> array(
					'type'              => 'string',
					'default'           => '',
					'sanitize_callback' => 'sanitize_text_field',
				),
				'openInNewTab'=> array( 'type' => 'boolean', 'default' => false ),
			),
		)
	);

	// Endpoint البحث السريع (بلوك tcf/courses-search)
	register_rest_route(
		'tcf/v1',
		'/search',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'tcf_rest_search_courses',
			'permission_callback' => '__return_true',
			'args'                => array(
				'q'           => array(
					'type'              => 'string',
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				),
				'perPage'     => array(
					'type'              => 'integer',
					'default'           => 6,
					'validate_callback' => function( $param ) {
						return is_numeric( $param ) && (int) $param >= 1 && (int) $param <= 12;
					},
				),
				'showThumb'   => array( 'type' => 'boolean', 'default' => true ),
				'showPrice'   => array( 'type' => 'boolean', 'default' => true ),
				'showRating'  => array( 'type' => 'boolean', 'default' => true ),
				'showStudents'=> array( 'type' => 'boolean', 'default' => true ),
				'openInNewTab'=> array( 'type' => 'boolean', 'default' => false ),
				'sentence'   => array( 'type' => 'boolean', 'default' => false ),
			),
		)
	);
}

/**
 * يعيد عنوان IP الزائر من REMOTE_ADDR فقط (بدون الاعتماد على الـ proxy headers
 * لتجنّب التزوير). يُستخدم لتحديد معدّل الطلبات (rate limit).
 */
function tcf_get_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return $ip ? $ip : 'unknown';
}

function tcf_rest_get_courses( $request ) {
	// تحديد معدّل بسيط لكل IP (transient قصير) — endpoint عام بلا مصادقة
	// Yلحمايته من الاستغلال كحمل متكرر على الاستعلام المجمّع.
	$rl_key   = 'tcf_rl_' . md5( tcf_get_client_ip() . TCF_VERSION );
	$rl_count = (int) get_transient( $rl_key ) + 1;
	set_transient( $rl_key, $rl_count, MINUTE_IN_SECONDS );
	if ( $rl_count > 60 ) {
		return new WP_Error( 'tcf_rate_limited', __( 'طلبات كثيرة جداً، حاول لاحقاً.', 'tutor-courses-filter-pro' ), array( 'status' => 429 ) );
	}

	$term_param = $request->get_param( 'term' );

	// أزرار التصنيف تحمل data-term="term-123"، فنزيل البادئة قبل التحويل.
	if ( is_string( $term_param ) && 0 === strpos( $term_param, 'term-' ) ) {
		$term_param = substr( $term_param, 5 );
	}

	$term = null;
	if ( 'all' !== $term_param ) {
		$term_id = (int) $term_param;
		if ( ! $term_id ) {
			return new WP_Error( 'tcf_invalid_term', __( 'تصنيف غير صالح', 'tutor-courses-filter-pro' ), array( 'status' => 404 ) );
		}
		$term = get_term( $term_id, 'course-category' );
		if ( is_wp_error( $term ) || ! $term ) {
			return new WP_Error( 'tcf_invalid_term', __( 'تصنيف غير صالح', 'tutor-courses-filter-pro' ), array( 'status' => 404 ) );
		}
	}

	$attributes = array(
		'orderby'     => $request->get_param( 'orderby' ),
		'perPage'     => min( 24, max( 1, (int) $request->get_param( 'perPage' ) ) ),
		'showLevel'   => (bool) $request->get_param( 'showLevel' ),
		'showRating'  => (bool) $request->get_param( 'showRating' ),
		'showLessons' => (bool) $request->get_param( 'showLessons' ),
		'showDuration'=> (bool) $request->get_param( 'showDuration' ),
		'showPrice'   => (bool) $request->get_param( 'showPrice' ),
		'showStudents'=> (bool) $request->get_param( 'showStudents' ),
		'showEnrollBtn'=> (bool) $request->get_param( 'showEnrollBtn' ),
		'enrollBtnText' => (string) $request->get_param( 'enrollBtnText' ),
		'openInNewTab' => (bool) $request->get_param( 'openInNewTab' ),
	);

	$page = min( 1000, max( 1, (int) $request->get_param( 'page' ) ) );

	$grid = tcf_render_category_grid_html( $term, $attributes, $page );

	return rest_ensure_response( array( 'html' => $grid['html'], 'hasMore' => $grid['has_more'] ) );
}

/**
 * REST: البحث السريع في الدورات.
 * GET /wp-json/tcf/v1/search?q=...&perPage=...
 *
 * يعيد HTML جاهزاً لعناصر النتائج (نفس أسلوب بطاقات الإضافة)، مع تحديد
 * معدّل طلبات مستقل (60/دقيقة/IP) كمسار عام بلا مصادقة.
 */
function tcf_rest_search_courses( $request ) {
	// Rate limit مستقل عن مسار /courses (60 طلب/دقيقة لكل IP)
	$rl_key   = 'tcf_rls_' . md5( tcf_get_client_ip() . TCF_VERSION );
	$rl_count = (int) get_transient( $rl_key ) + 1;
	set_transient( $rl_key, $rl_count, MINUTE_IN_SECONDS );
	if ( $rl_count > 60 ) {
		return new WP_Error( 'tcf_rate_limited', __( 'طلبات كثيرة جداً، حاول لاحقاً.', 'tutor-courses-filter-pro' ), array( 'status' => 429 ) );
	}

	$per_page = max( 1, min( 12, (int) $request->get_param( 'perPage' ) ) );
	$q        = tcf_sanitize_search_query( $request->get_param( 'q' ) );

	if ( '' === $q ) {
		return new WP_Error( 'tcf_empty_query', __( 'نص البحث فارغ', 'tutor-courses-filter-pro' ), array( 'status' => 400 ) );
	}

	$flags = array(
		'show_thumb'    => (bool) $request->get_param( 'showThumb' ),
		'show_price'    => (bool) $request->get_param( 'showPrice' ),
		'show_rating'   => (bool) $request->get_param( 'showRating' ),
		'show_students' => (bool) $request->get_param( 'showStudents' ),
		'open_new'      => (bool) $request->get_param( 'openInNewTab' ),
		'sentence'      => (bool) $request->get_param( 'sentence' ),
	);

	$html = tcf_search_courses_html( $q, $per_page, $flags );

	return rest_ensure_response( array(
		'html' => $html,
		'q'    => $q,
	) );
}
